# RunTrack v1.0 (Android starter project)

A dark, bilingual-ready GPS running tracker starter project.

## Features in this first build
- GPS location tracking using Android LocationManager
- Foreground location service for continued tracking while screen is off
- Elapsed time, distance and average pace
- Dark sports-style interface
- Bengali/English button and labels

## Important limitations in this starter
- This is source code, not a compiled APK.
- Run history, route map, calorie estimates, pause/resume and full localization are planned for the next version.
- GPS accuracy depends on phone hardware, clear sky, permissions and battery settings.
- Test outdoors before relying on measurements. Do not use this as a safety-critical navigation device.

## Build
Open this folder as an Android project in Android Studio or a compatible Android IDE, allow Gradle sync, then choose Build > Build APK(s).
Package: com.runtrack.app
Minimum Android: 8.0 (API 26)
Target SDK: 35
