package com.runtrack.app;

import android.app.*;
import android.content.*;
import android.location.Location;
import android.os.*;
import android.location.LocationListener;
import android.location.LocationManager;
import java.util.Locale;

public class RunningService extends Service implements LocationListener {
    public static final String ACTION_UPDATE = "com.runtrack.UPDATE";
    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    private LocationManager manager;
    private Location previous;
    private long startTime;
    private double meters = 0;
    private boolean running = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (running) { broadcast(); handler.postDelayed(this, 1000); }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        String action = intent == null ? "" : intent.getAction();
        if (ACTION_START.equals(action) && !running) {
            startTime = System.currentTimeMillis();
            meters = 0; previous = null; running = true;
            startForeground(7, notification("Run in progress"));
            try {
                manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this, Looper.getMainLooper());
                manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000, 3, this, Looper.getMainLooper());
            } catch (SecurityException ignored) {}
            handler.post(ticker);
        } else if (ACTION_STOP.equals(action)) {
            running = false;
            handler.removeCallbacks(ticker);
            try { manager.removeUpdates(this); } catch (Exception ignored) {}
            broadcast();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override public void onLocationChanged(Location loc) {
        if (!running || loc == null || loc.getAccuracy() > 35) return;
        if (previous != null) {
            float d = previous.distanceTo(loc);
            if (d > 0.8f && d < 100) meters += d;
        }
        previous = loc;
        broadcast();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7, notification("Distance: " + String.format(Locale.US, "%.2f km", meters/1000)));
    }

    private void broadcast() {
        Intent i = new Intent(ACTION_UPDATE);
        i.setPackage(getPackageName());
        i.putExtra("seconds", (System.currentTimeMillis()-startTime)/1000);
        i.putExtra("meters", meters);
        i.putExtra("running", running);
        sendBroadcast(i);
    }

    private Notification notification(String text) {
        return new Notification.Builder(this, "runtrack")
            .setContentTitle("RunTrack")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true).build();
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("runtrack", "Running tracker", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    @Override public void onProviderEnabled(String p) {}
    @Override public void onProviderDisabled(String p) {}
    @Override public void onStatusChanged(String p, int s, Bundle b) {}
    @Override public IBinder onBind(Intent i) { return null; }
}
