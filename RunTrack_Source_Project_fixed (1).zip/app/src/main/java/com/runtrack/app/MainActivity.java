package com.runtrack.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView timeText, distanceText, paceText, statusText, titleText;
    private Button runButton, languageButton;
    private boolean bengali = true, active = false;
    private long seconds = 0;
    private double meters = 0;
    private BroadcastReceiver receiver;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                seconds = i.getLongExtra("seconds", 0);
                meters = i.getDoubleExtra("meters", 0);
                active = i.getBooleanExtra("running", false);
                updateStats();
            }
        };
        IntentFilter filter = new IntentFilter(RunningService.ACTION_UPDATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
        updateLabels();
    }

    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); return t;
    }
    private void buildUi() {
        LinearLayout base = new LinearLayout(this); base.setOrientation(1); base.setPadding(dp(22),dp(24),dp(22),dp(20)); base.setBackgroundColor(Color.rgb(9,11,13));
        setContentView(base);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        titleText = text("RUNTRACK", 23, Color.WHITE); titleText.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT); titleText.setTypeface(null,1);
        top.addView(titleText,new LinearLayout.LayoutParams(0,dp(55),1));
        languageButton = new Button(this); languageButton.setText("বাংলা / EN"); languageButton.setTextSize(11);
        top.addView(languageButton); base.addView(top);
        languageButton.setOnClickListener(v->{bengali=!bengali;updateLabels();});
        TextView subtitle=text("YOUR RUN. YOUR PROGRESS.",12,0xff9da5ad); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(42)); sp.topMargin=dp(10); base.addView(subtitle,sp);
        statusText=text("READY TO RUN",13,0xffb8ff3b); LinearLayout.LayoutParams st=new LinearLayout.LayoutParams(-1,dp(45)); st.topMargin=dp(22); base.addView(statusText,st);
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(1); stats.setGravity(Gravity.CENTER); stats.setBackgroundColor(0xff171c20);
        stats.setPadding(dp(10),dp(22),dp(10),dp(22));
        timeText=text("00:00:00",38,Color.WHITE); timeText.setTypeface(null,1); stats.addView(timeText,new LinearLayout.LayoutParams(-1,dp(72)));
        TextView timeLabel=text("TIME",11,0xff9da5ad); stats.addView(timeLabel);
        LinearLayout row=new LinearLayout(this); row.setPadding(0,dp(24),0,dp(5));
        LinearLayout left=new LinearLayout(this); left.setOrientation(1); left.setGravity(Gravity.CENTER);
        distanceText=text("0.00 km",27,0xffb8ff3b); distanceText.setTypeface(null,1);
        left.addView(distanceText); left.addView(text("DISTANCE",11,0xff9da5ad));
        LinearLayout right=new LinearLayout(this); right.setOrientation(1); right.setGravity(Gravity.CENTER);
        paceText=text("--:-- /km",27,Color.WHITE); paceText.setTypeface(null,1);
        right.addView(paceText); right.addView(text("PACE",11,0xff9da5ad));
        row.addView(left,new LinearLayout.LayoutParams(0,dp(80),1)); row.addView(right,new LinearLayout.LayoutParams(0,dp(80),1));
        stats.addView(row); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,0,1); cp.topMargin=dp(10); base.addView(stats,cp);
        runButton=new Button(this); runButton.setTextSize(18); runButton.setAllCaps(false); runButton.setText("START RUN");
        runButton.setTextColor(0xff101510); runButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffb8ff3b));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(60)); bp.topMargin=dp(22); base.addView(runButton,bp);
        runButton.setOnClickListener(v->toggleRun());
        TextView foot=text("GPS REQUIRED  •  OUTDOOR RUNNING",10,0xff737d85); LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(45)); base.addView(foot,fp);
    }

    private void updateLabels() {
        titleText.setText(bengali ? "RUNTRACK" : "RUNTRACK");
        runButton.setText(active ? (bengali?"দৌড় শেষ করুন":"STOP RUN") : (bengali?"দৌড় শুরু করুন":"START RUN"));
        statusText.setText(active ? (bengali?"দৌড় চলছে":"RUN IN PROGRESS") : (bengali?"দৌড়ের জন্য প্রস্তুত":"READY TO RUN"));
    }
    private void updateStats() {
        long h=seconds/3600, m=(seconds%3600)/60, s=seconds%60;
        timeText.setText(String.format(Locale.US,"%02d:%02d:%02d",h,m,s));
        distanceText.setText(String.format(Locale.US,"%.2f km",meters/1000));
        if (meters > 10) {
            double pace=(seconds/60.0)/(meters/1000.0);
            paceText.setText(String.format(Locale.US,"%02d:%02d /km",(int)pace,(int)((pace%1)*60)));
        } else paceText.setText("--:-- /km");
        updateLabels();
    }
    private void toggleRun() {
        if (!active) {
            boolean hasLoc = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
            if (!hasLoc) {
                if (Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.POST_NOTIFICATIONS},9);
                else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},9);
                return;
            }
            Intent i=new Intent(this,RunningService.class); i.setAction(RunningService.ACTION_START);
            if (Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            active=true; updateLabels();
        } else {
            Intent i=new Intent(this,RunningService.class); i.setAction(RunningService.ACTION_STOP); startService(i);
            active=false; updateLabels();
        }
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g) { super.onRequestPermissionsResult(r,p,g); if(r==9) { if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) toggleRun(); else Toast.makeText(this, bengali?"সঠিক লোকেশন (Precise) অনুমতি দিন":"Please allow Precise location", Toast.LENGTH_LONG).show(); } }
    @Override protected void onDestroy() { super.onDestroy(); if(receiver!=null) unregisterReceiver(receiver); }
}
