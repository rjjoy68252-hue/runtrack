package com.runtrack.app;

import android.location.Location;
import android.os.SystemClock;

import java.util.ArrayList;

/**
 * Live state of the current run. The service and the activity run in the same
 * process and both on the main thread, so plain static fields are enough.
 */
final class RunState {
    static boolean active;
    static boolean paused;
    static double meters;
    static long accumulatedMs;   // time of finished segments
    static long segmentStart;    // elapsedRealtime when the current segment began
    static long startWall;       // wall-clock start, used as the run id
    static Location last;
    static final ArrayList<double[]> points = new ArrayList<>();

    private RunState() {}

    static void begin() {
        reset();
        active = true;
        startWall = System.currentTimeMillis();
        segmentStart = SystemClock.elapsedRealtime();
    }

    static void reset() {
        active = false;
        paused = false;
        meters = 0;
        accumulatedMs = 0;
        segmentStart = 0;
        startWall = 0;
        last = null;
        points.clear();
    }

    static long elapsedMs() {
        if (!active) return 0;
        long e = accumulatedMs;
        if (!paused) e += SystemClock.elapsedRealtime() - segmentStart;
        return e;
    }

    static void pause() {
        if (active && !paused) {
            accumulatedMs += SystemClock.elapsedRealtime() - segmentStart;
            paused = true;
            last = null; // do not count the jump after resuming
        }
    }

    static void resume() {
        if (active && paused) {
            segmentStart = SystemClock.elapsedRealtime();
            paused = false;
        }
    }

    static void onLocation(Location l) {
        if (!active || paused) return;
        if (l.hasAccuracy() && l.getAccuracy() > 30f) return;
        if (last == null) {
            last = l;
            points.add(new double[]{l.getLatitude(), l.getLongitude()});
            return;
        }
        float d = last.distanceTo(l);
        double dt = (l.getElapsedRealtimeNanos() - last.getElapsedRealtimeNanos()) / 1e9;
        if (dt > 30) {
            // long GPS gap: restart from the new position without adding distance
            last = l;
            points.add(new double[]{l.getLatitude(), l.getLongitude()});
            return;
        }
        if (d < 3f) return;                    // standing still / GPS jitter
        if (dt > 0 && d / dt > 12.0) return;   // faster than 43 km/h: bad fix
        meters += d;
        last = l;
        points.add(new double[]{l.getLatitude(), l.getLongitude()});
    }

    /** Ends the run. Returns the finished run, or null if it was too short to keep. */
    static Run finishRun() {
        if (!active) return null;
        if (!paused) {
            accumulatedMs += SystemClock.elapsedRealtime() - segmentStart;
        }
        long sec = accumulatedMs / 1000;
        double m = meters;
        Run r = null;
        if (m >= 20 && sec >= 10) {
            r = new Run(startWall, sec, m, Fmt.calories(m), Run.encode(points));
        }
        reset();
        return r;
    }
}
