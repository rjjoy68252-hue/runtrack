package com.runtrack.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Draws a run route (list of {lat, lon}) as a neon line. No map tiles, no internet. */
public class RouteView extends View {
    private List<double[]> pts = new ArrayList<>();
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint startDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint endDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public RouteView(Context c) {
        super(c);
        line.setColor(UI.ACCENT);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(UI.dp(c, 4));
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        startDot.setColor(0xFFFFFFFF);
        endDot.setColor(UI.ACCENT);
        setBackground(UI.round(0xFF0F1316, 12, c));
    }

    void setPoints(List<double[]> p) {
        pts = p;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        int n = pts.size();
        if (n < 2) return;

        double minLat = Double.MAX_VALUE, maxLat = -Double.MAX_VALUE;
        double minLon = Double.MAX_VALUE, maxLon = -Double.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            double[] p = pts.get(i);
            minLat = Math.min(minLat, p[0]);
            maxLat = Math.max(maxLat, p[0]);
            minLon = Math.min(minLon, p[1]);
            maxLon = Math.max(maxLon, p[1]);
        }
        double cosLat = Math.cos(Math.toRadians((minLat + maxLat) / 2));
        double w = (maxLon - minLon) * cosLat;
        double h = maxLat - minLat;

        float pad = UI.dp(getContext(), 16);
        float availW = getWidth() - 2 * pad;
        float availH = getHeight() - 2 * pad;
        if (availW <= 0 || availH <= 0) return;

        double scale;
        if (w <= 1e-9 && h <= 1e-9) {
            scale = 1;
        } else if (w <= 1e-9) {
            scale = availH / h;
        } else if (h <= 1e-9) {
            scale = availW / w;
        } else {
            scale = Math.min(availW / w, availH / h);
        }
        float offX = (float) (pad + (availW - w * scale) / 2);
        float offY = (float) (pad + (availH - h * scale) / 2);

        path.reset();
        float sx = 0, sy = 0, ex = 0, ey = 0;
        for (int i = 0; i < n; i++) {
            double[] p = pts.get(i);
            float x = (float) (offX + (p[1] - minLon) * cosLat * scale);
            float y = (float) (offY + (maxLat - p[0]) * scale);
            if (i == 0) {
                path.moveTo(x, y);
                sx = x;
                sy = y;
            } else {
                path.lineTo(x, y);
            }
            ex = x;
            ey = y;
        }
        cv.drawPath(path, line);
        cv.drawCircle(sx, sy, UI.dp(getContext(), 5), startDot);
        cv.drawCircle(ex, ey, UI.dp(getContext(), 6), endDot);
    }
}
