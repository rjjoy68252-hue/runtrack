package com.runtrack.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int REQ_LOCATION = 11;

    private interface IntSaver {
        void save(int v);
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout content;
    private final TextView[] navIcon = new TextView[4];
    private final TextView[] navLabel = new TextView[4];
    private int tab = 0; // 0 run, 1 history, 2 stats, 3 settings

    // run screen views (null when another tab is showing)
    private TextView statusText, timeText, distText, paceText, calText;
    private Button startStopBtn, pauseBtn;
    private RouteView routeView;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (tab == 0 && timeText != null) updateRunUi();
            handler.postDelayed(this, 1000);
        }
    };

    // ------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Prefs.init(this);
        getWindow().getDecorView().setBackgroundColor(UI.BG);
        buildAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    // ------------------------------------------------------------------
    // frame: top bar, content, bottom nav, developer footer
    // ------------------------------------------------------------------

    private void buildAll() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        root.setFitsSystemWindows(true);

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(MATCH, WRAP));
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        root.addView(buildNav(), new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(buildFooter(), new LinearLayout.LayoutParams(MATCH, WRAP));

        setContentView(root);
        showTab(tab);
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int p = UI.dp(this, 16);
        bar.setPadding(p, UI.dp(this, 8), p, UI.dp(this, 8));

        TextView title = UI.tv(this, "RUNTRACK", 24, UI.TEXT, true);
        bar.addView(title, new LinearLayout.LayoutParams(0, WRAP, 1f));

        Button lang = UI.button(this, "বাংলা / EN", false);
        lang.setTextSize(13);
        lang.setPadding(UI.dp(this, 14), UI.dp(this, 8), UI.dp(this, 14), UI.dp(this, 8));
        lang.setOnClickListener(v -> {
            Prefs.setBengali(!Prefs.bengali());
            buildAll();
        });
        bar.addView(lang, new LinearLayout.LayoutParams(WRAP, WRAP));
        return bar;
    }

    private View buildNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(0xFF111518);

        String[] icons = {"🏃", "📋", "📊", "⚙️"};
        String[] labels = {
                L.s("Run", "দৌড়"),
                L.s("History", "ইতিহাস"),
                L.s("Stats", "পরিসংখ্যান"),
                L.s("Settings", "সেটিংস")
        };
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(0, UI.dp(this, 8), 0, UI.dp(this, 8));
            navIcon[i] = UI.tv(this, icons[i], 20, UI.MUTED, false);
            navLabel[i] = UI.tv(this, labels[i], 11, UI.MUTED, true);
            item.addView(navIcon[i], new LinearLayout.LayoutParams(WRAP, WRAP));
            item.addView(navLabel[i], new LinearLayout.LayoutParams(WRAP, WRAP));
            item.setOnClickListener(v -> showTab(idx));
            nav.addView(item, new LinearLayout.LayoutParams(0, WRAP, 1f));
        }
        return nav;
    }

    /** Developer credit: shown at the very bottom of every screen. */
    private View buildFooter() {
        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.CENTER);
        footer.setBackgroundColor(0xFF050607);
        footer.setPadding(UI.dp(this, 12), UI.dp(this, 8), UI.dp(this, 12), UI.dp(this, 8));

        TextView name = UI.tv(this,
                L.s("Developed by ", "তৈরি করেছেন ") + UI.DEV_NAME,
                11, UI.MUTED, false);
        TextView fb = UI.tv(this, "  •  Facebook", 11, UI.ACCENT, true);
        footer.addView(name, new LinearLayout.LayoutParams(WRAP, WRAP));
        footer.addView(fb, new LinearLayout.LayoutParams(WRAP, WRAP));
        footer.setOnClickListener(v -> openFacebook());
        return footer;
    }

    private void openFacebook() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(UI.FB_URL)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, UI.FB_URL, Toast.LENGTH_LONG).show();
        }
    }

    private void showTab(int t) {
        tab = t;
        statusText = null;
        timeText = null;
        distText = null;
        paceText = null;
        calText = null;
        startStopBtn = null;
        pauseBtn = null;
        routeView = null;
        content.removeAllViews();

        View v;
        switch (t) {
            case 0:
                v = buildRunScreen();
                break;
            case 1:
                v = buildHistoryScreen();
                break;
            case 2:
                v = buildStatsScreen();
                break;
            default:
                v = buildSettingsScreen();
                break;
        }
        content.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));

        for (int i = 0; i < 4; i++) {
            boolean sel = (i == t);
            navLabel[i].setTextColor(sel ? UI.ACCENT : UI.MUTED);
            navIcon[i].setAlpha(sel ? 1f : 0.45f);
        }
        if (t == 0) updateRunUi();
    }

    // ------------------------------------------------------------------
    // small layout helpers
    // ------------------------------------------------------------------

    private LinearLayout.LayoutParams params(int w, int h, float weight, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.topMargin = UI.dp(this, topDp);
        return p;
    }

    private LinearLayout pageColumn() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 16);
        col.setPadding(p, UI.dp(this, 4), p, p);
        return col;
    }

    private ScrollView scroll(LinearLayout col) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(col, new ViewGroup.LayoutParams(MATCH, WRAP));
        return sv;
    }

    private View statBlock(TextView value, String label) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER_HORIZONTAL);
        value.setGravity(Gravity.CENTER);
        b.addView(value, new LinearLayout.LayoutParams(WRAP, WRAP));
        b.addView(UI.tv(this, label, 11, UI.MUTED, true), new LinearLayout.LayoutParams(WRAP, WRAP));
        return b;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(UI.LINE);
        return d;
    }

    private LinearLayout.LayoutParams dividerParams() {
        return new LinearLayout.LayoutParams(MATCH, UI.dp(this, 1));
    }

    // ------------------------------------------------------------------
    // RUN screen
    // ------------------------------------------------------------------

    private View buildRunScreen() {
        LinearLayout col = pageColumn();

        statusText = UI.tv(this, "", 16, UI.ACCENT, true);
        statusText.setGravity(Gravity.CENTER);
        col.addView(statusText, params(MATCH, WRAP, 0, 4));

        TextView tag = UI.tv(this,
                L.s("YOUR RUN. YOUR PROGRESS.",
                        "আপনার দৌড়। আপনার অগ্রগতি।"),
                12, UI.MUTED, true);
        tag.setGravity(Gravity.CENTER);
        col.addView(tag, params(MATCH, WRAP, 0, 4));

        LinearLayout card = UI.card(this);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setMinimumHeight(UI.dp(this, 320));

        timeText = UI.tv(this, "00:00:00", 54, UI.TEXT, true);
        timeText.setGravity(Gravity.CENTER);
        card.addView(timeText, params(WRAP, WRAP, 0, 24));
        card.addView(UI.tv(this, L.s("TIME", "সময়"), 12, UI.MUTED, true),
                params(WRAP, WRAP, 0, 0));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        distText = UI.tv(this, "0.00 km", 24, UI.ACCENT, true);
        paceText = UI.tv(this, "--:-- /km", 24, UI.TEXT, true);
        calText = UI.tv(this, "0 kcal", 24, UI.TEXT, true);
        stats.addView(statBlock(distText, L.s("DISTANCE", "দূরত্ব")),
                new LinearLayout.LayoutParams(0, WRAP, 1f));
        stats.addView(statBlock(paceText, L.s("PACE", "পেস")),
                new LinearLayout.LayoutParams(0, WRAP, 1f));
        stats.addView(statBlock(calText, L.s("CALORIES", "ক্যালোরি")),
                new LinearLayout.LayoutParams(0, WRAP, 1f));
        card.addView(stats, params(MATCH, WRAP, 0, 28));

        routeView = new RouteView(this);
        routeView.setVisibility(View.GONE);
        card.addView(routeView, params(MATCH, UI.dp(this, 180), 0, 20));
        col.addView(card, params(MATCH, WRAP, 0, 12));

        col.addView(goalCard(), params(MATCH, WRAP, 0, 12));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        startStopBtn = UI.button(this, "", true);
        pauseBtn = UI.button(this, "", false);
        pauseBtn.setVisibility(View.GONE);
        row.addView(startStopBtn, new LinearLayout.LayoutParams(0, WRAP, 1f));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        pp.leftMargin = UI.dp(this, 10);
        row.addView(pauseBtn, pp);
        col.addView(row, params(MATCH, WRAP, 0, 12));

        startStopBtn.setOnClickListener(v -> {
            if (RunState.active) {
                stopRun();
            } else {
                startRunFlow();
            }
        });
        pauseBtn.setOnClickListener(v -> {
            if (RunState.paused) {
                RunState.resume();
            } else {
                RunState.pause();
            }
            updateRunUi();
        });

        TextView hint = UI.tv(this, "GPS REQUIRED  •  OUTDOOR RUNNING", 11, UI.MUTED, true);
        hint.setGravity(Gravity.CENTER);
        col.addView(hint, params(MATCH, WRAP, 0, 12));

        return scroll(col);
    }

    private void updateRunUi() {
        if (timeText == null) return;
        boolean act = RunState.active;
        boolean pz = RunState.paused;

        if (!act) {
            statusText.setText(L.s("READY TO RUN",
                    "দৌড়ের জন্য প্রস্তুত"));
        } else if (pz) {
            statusText.setText(L.s("PAUSED", "বিরতি"));
        } else {
            statusText.setText(L.s("RUN IN PROGRESS", "দৌড় চলছে"));
        }

        long sec = RunState.elapsedMs() / 1000;
        double m = RunState.meters;
        timeText.setText(Fmt.clock(sec));
        distText.setText(Fmt.dist(m));
        paceText.setText(Fmt.paceWithUnit(m, sec));
        calText.setText(Fmt.calories(m) + " kcal");

        if (act) {
            startStopBtn.setText(L.s("STOP RUN", "দৌড় শেষ করুন"));
            startStopBtn.setTextColor(UI.TEXT);
            startStopBtn.setBackground(UI.round(UI.DANGER, 12, this));
            pauseBtn.setVisibility(View.VISIBLE);
            pauseBtn.setText(pz ? L.s("RESUME", "চালু করুন")
                    : L.s("PAUSE", "বিরতি"));
        } else {
            startStopBtn.setText(L.s("START RUN", "দৌড় শুরু করুন"));
            startStopBtn.setTextColor(UI.BG);
            startStopBtn.setBackground(UI.round(UI.ACCENT, 12, this));
            pauseBtn.setVisibility(View.GONE);
        }

        if (RunState.points.size() >= 2) {
            routeView.setPoints(RunState.points);
            routeView.setVisibility(View.VISIBLE);
        } else {
            routeView.setVisibility(View.GONE);
        }

        if (act && Prefs.keepScreenOn()) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void startRunFlow() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ArrayList<String> perms = new ArrayList<>();
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION);
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            if (Build.VERSION.SDK_INT >= 33) {
                perms.add(Manifest.permission.POST_NOTIFICATIONS);
            }
            requestPermissions(perms.toArray(new String[0]), REQ_LOCATION);
            return;
        }
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm == null || !lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this,
                    L.s("Please turn on GPS", "অনুগ্রহ করে GPS চালু করুন"),
                    Toast.LENGTH_LONG).show();
            return;
        }
        RunState.begin();
        Intent i = new Intent(this, RunningService.class);
        i.setAction(RunningService.ACTION_START);
        startForegroundService(i);
        updateRunUi();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_LOCATION) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            startRunFlow();
        } else {
            Toast.makeText(this,
                    L.s("Please allow Precise location",
                            "অনুগ্রহ করে Precise location অনুমতি দিন"),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void stopRun() {
        Run r = RunState.finishRun();
        Intent i = new Intent(this, RunningService.class);
        i.setAction(RunningService.ACTION_STOP);
        startService(i);
        if (r != null) {
            Prefs.addRun(r);
            new AlertDialog.Builder(this)
                    .setTitle(L.s("Run saved", "দৌড় সেভ হয়েছে"))
                    .setMessage(summaryText(r))
                    .setPositiveButton("OK", null)
                    .show();
        } else {
            Toast.makeText(this,
                    L.s("Run too short, not saved",
                            "দৌড় খুব ছোট, সেভ হয়নি"),
                    Toast.LENGTH_SHORT).show();
        }
        updateRunUi();
    }

    private String summaryText(Run r) {
        return L.s("Distance: ", "দূরত্ব: ") + Fmt.dist(r.meters) + "\n"
                + L.s("Time: ", "সময়: ") + Fmt.clock(r.seconds) + "\n"
                + L.s("Pace: ", "পেস: ") + Fmt.paceWithUnit(r.meters, r.seconds) + "\n"
                + L.s("Calories: ", "ক্যালোরি: ") + r.calories + " kcal";
    }

    // ------------------------------------------------------------------
    // weekly goal helpers
    // ------------------------------------------------------------------

    private Calendar todayStart() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    private long weekStartMillis() {
        Calendar c = todayStart();
        int dow = c.get(Calendar.DAY_OF_WEEK); // Sunday = 1
        int sinceMonday = (dow + 5) % 7;
        c.add(Calendar.DAY_OF_YEAR, -sinceMonday);
        return c.getTimeInMillis();
    }

    private double metersSince(List<Run> runs, long from) {
        double total = 0;
        for (Run r : runs) {
            if (r.id >= from) total += r.meters;
        }
        return total;
    }

    private View goalCard() {
        LinearLayout card = UI.card(this);
        List<Run> runs = Prefs.runs();
        double done = metersSince(runs, weekStartMillis());
        int goal = Prefs.weeklyGoal();
        double goalMeters = goal * Fmt.unitMeters();
        float frac = (float) Math.max(0, Math.min(1, done / goalMeters));

        card.addView(UI.tv(this, L.s("WEEKLY GOAL", "সাপ্তাহিক লক্ষ্য"),
                12, UI.MUTED, true));
        String val = String.format(Locale.US, "%.2f / %d %s", done / Fmt.unitMeters(), goal, Fmt.unit());
        card.addView(UI.tv(this, val, 18, UI.TEXT, true), params(WRAP, WRAP, 0, 4));

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(UI.LINE);
        View fill = new View(this);
        fill.setBackgroundColor(UI.ACCENT);
        View rest = new View(this);
        bar.addView(fill, new LinearLayout.LayoutParams(0, MATCH, frac));
        bar.addView(rest, new LinearLayout.LayoutParams(0, MATCH, 1f - frac));
        card.addView(bar, params(MATCH, UI.dp(this, 10), 0, 10));
        return card;
    }

    // ------------------------------------------------------------------
    // HISTORY screen
    // ------------------------------------------------------------------

    private View buildHistoryScreen() {
        LinearLayout col = pageColumn();
        col.addView(UI.tv(this, L.s("History", "ইতিহাস"), 24, UI.TEXT, true));

        List<Run> runs = Prefs.runs();
        if (runs.isEmpty()) {
            col.addView(UI.tv(this,
                    L.s("No runs yet. Start your first run!",
                            "এখনও কোনো দৌড় নেই। প্রথম দৌড় শুরু করুন!"),
                    15, UI.MUTED, false), params(WRAP, WRAP, 0, 24));
        }
        for (final Run r : runs) {
            col.addView(runCard(r), params(MATCH, WRAP, 0, 12));
        }
        return scroll(col);
    }

    private View runCard(final Run r) {
        LinearLayout card = UI.card(this);
        card.addView(UI.tv(this, Fmt.date(r.id), 13, UI.MUTED, false));
        card.addView(UI.tv(this, Fmt.dist(r.meters), 28, UI.ACCENT, true), params(WRAP, WRAP, 0, 4));
        String line = Fmt.clock(r.seconds) + "  •  " + Fmt.paceWithUnit(r.meters, r.seconds)
                + "  •  " + r.calories + " kcal";
        card.addView(UI.tv(this, line, 14, UI.TEXT, false), params(WRAP, WRAP, 0, 4));
        card.setOnClickListener(v -> showRunDetail(r));
        return card;
    }

    private void showRunDetail(final Run r) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 16);
        box.setPadding(p, p, p, p);

        RouteView rv = new RouteView(this);
        rv.setPoints(r.points());
        box.addView(rv, new LinearLayout.LayoutParams(MATCH, UI.dp(this, 200)));
        box.addView(UI.tv(this, summaryText(r), 15, UI.TEXT, false), params(WRAP, WRAP, 0, 12));

        new AlertDialog.Builder(this)
                .setTitle(Fmt.date(r.id))
                .setView(box)
                .setPositiveButton(L.s("Close", "বন্ধ"), null)
                .setNegativeButton(L.s("Delete", "মুছুন"), (d, w) -> {
                    Prefs.deleteRun(r.id);
                    showTab(1);
                })
                .show();
    }

    // ------------------------------------------------------------------
    // STATS screen
    // ------------------------------------------------------------------

    private View buildStatsScreen() {
        LinearLayout col = pageColumn();
        col.addView(UI.tv(this, L.s("Stats", "পরিসংখ্যান"), 24, UI.TEXT, true));

        List<Run> runs = Prefs.runs();
        double totalM = 0;
        long totalS = 0;
        int totalCal = 0;
        double longest = 0;
        double bestPace = 0; // seconds per unit, lower is better
        for (Run r : runs) {
            totalM += r.meters;
            totalS += r.seconds;
            totalCal += r.calories;
            if (r.meters > longest) longest = r.meters;
            if (r.meters >= 500) {
                double sp = r.seconds / (r.meters / Fmt.unitMeters());
                if (bestPace == 0 || sp < bestPace) bestPace = sp;
            }
        }

        col.addView(goalCard(), params(MATCH, WRAP, 0, 12));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(statCard(L.s("RUNS", "দৌড়"), String.valueOf(runs.size())),
                new LinearLayout.LayoutParams(0, WRAP, 1f));
        row1.addView(statCard(L.s("TOTAL DISTANCE", "মোট দূরত্ব"), Fmt.dist(totalM)),
                gapParams());
        col.addView(row1, params(MATCH, WRAP, 0, 12));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(statCard(L.s("TOTAL TIME", "মোট সময়"), Fmt.clock(totalS)),
                new LinearLayout.LayoutParams(0, WRAP, 1f));
        row2.addView(statCard(L.s("CALORIES", "ক্যালোরি"), totalCal + " kcal"),
                gapParams());
        col.addView(row2, params(MATCH, WRAP, 0, 12));

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        row3.addView(statCard(L.s("LONGEST RUN", "সবচেয় বড় দৌড়"), Fmt.dist(longest)),
                new LinearLayout.LayoutParams(0, WRAP, 1f));
        String best = "--:--";
        if (bestPace > 0) {
            long p = Math.round(bestPace);
            best = String.format(Locale.US, "%02d:%02d /%s", p / 60, p % 60, Fmt.unit());
        }
        row3.addView(statCard(L.s("BEST PACE", "সেরা পেস"), best), gapParams());
        col.addView(row3, params(MATCH, WRAP, 0, 12));

        col.addView(weekChart(runs), params(MATCH, WRAP, 0, 12));
        return scroll(col);
    }

    private LinearLayout.LayoutParams gapParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WRAP, 1f);
        p.leftMargin = UI.dp(this, 10);
        return p;
    }

    private View statCard(String label, String value) {
        LinearLayout card = UI.card(this);
        card.addView(UI.tv(this, label, 11, UI.MUTED, true));
        card.addView(UI.tv(this, value, 20, UI.TEXT, true), params(WRAP, WRAP, 0, 4));
        return card;
    }

    private View weekChart(List<Run> runs) {
        LinearLayout card = UI.card(this);
        card.addView(UI.tv(this, L.s("LAST 7 DAYS", "গত ৭ দিন"), 12, UI.MUTED, true));

        double[] sums = new double[7];
        String[] days = new String[7];
        double max = 1;
        SimpleDateFormat fmt = new SimpleDateFormat("EEE", Locale.US);
        for (int i = 6; i >= 0; i--) {
            Calendar c = todayStart();
            c.add(Calendar.DAY_OF_YEAR, -i);
            long from = c.getTimeInMillis();
            c.add(Calendar.DAY_OF_YEAR, 1);
            long to = c.getTimeInMillis();
            double s = 0;
            for (Run r : runs) {
                if (r.id >= from && r.id < to) s += r.meters;
            }
            int idx = 6 - i;
            sums[idx] = s;
            days[idx] = fmt.format(new java.util.Date(from));
            if (s > max) max = s;
        }

        LinearLayout bars = new LinearLayout(this);
        bars.setOrientation(LinearLayout.HORIZONTAL);
        bars.setGravity(Gravity.BOTTOM);
        int maxBar = UI.dp(this, 100);
        for (int i = 0; i < 7; i++) {
            LinearLayout colm = new LinearLayout(this);
            colm.setOrientation(LinearLayout.VERTICAL);
            colm.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);

            TextView val = UI.tv(this, sums[i] > 0 ? Fmt.distNum(sums[i]) : "", 10, UI.MUTED, false);
            colm.addView(val, new LinearLayout.LayoutParams(WRAP, WRAP));

            View bar = new View(this);
            bar.setBackground(UI.round(sums[i] > 0 ? UI.ACCENT : UI.LINE, 4, this));
            int h = Math.max(UI.dp(this, 3), (int) (maxBar * sums[i] / max));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(UI.dp(this, 18), h);
            bp.topMargin = UI.dp(this, 4);
            colm.addView(bar, bp);

            TextView day = UI.tv(this, days[i], 10, UI.MUTED, true);
            colm.addView(day, params(WRAP, WRAP, 0, 4));
            bars.addView(colm, new LinearLayout.LayoutParams(0, WRAP, 1f));
        }
        card.addView(bars, params(MATCH, WRAP, 0, 12));
        return card;
    }

    // ------------------------------------------------------------------
    // SETTINGS screen (with About)
    // ------------------------------------------------------------------

    private View buildSettingsScreen() {
        LinearLayout col = pageColumn();
        col.addView(UI.tv(this, L.s("Settings", "সেটিংস"), 24, UI.TEXT, true));

        LinearLayout card = UI.card(this);

        // language
        Button langBtn = UI.button(this, Prefs.bengali() ? "বাংলা" : "English", false);
        langBtn.setOnClickListener(v -> {
            Prefs.setBengali(!Prefs.bengali());
            buildAll();
        });
        card.addView(settingRow(L.s("Language", "ভাষা"), langBtn));
        card.addView(divider(), dividerParams());

        // units
        Button unitBtn = UI.button(this, Prefs.miles() ? "Miles (mi)" : "Kilometers (km)", false);
        unitBtn.setOnClickListener(v -> {
            Prefs.setMiles(!Prefs.miles());
            showTab(3);
        });
        card.addView(settingRow(L.s("Distance unit", "দূরত্বের একক"), unitBtn));
        card.addView(divider(), dividerParams());

        // weight
        card.addView(settingRow(L.s("Body weight (for calories)", "ওজন (ক্যালোরির জন্য)"),
                stepper(new int[]{Prefs.weightKg()}, 30, 200, "kg", Prefs::setWeightKg)));
        card.addView(divider(), dividerParams());

        // weekly goal
        card.addView(settingRow(L.s("Weekly goal", "সাপ্তাহিক লক্ষ্য"),
                stepper(new int[]{Prefs.weeklyGoal()}, 1, 500, Fmt.unit(), Prefs::setWeeklyGoal)));
        card.addView(divider(), dividerParams());

        // keep screen on
        Switch keep = new Switch(this);
        keep.setChecked(Prefs.keepScreenOn());
        keep.setOnCheckedChangeListener((b, checked) -> Prefs.setKeepScreenOn(checked));
        card.addView(settingRow(L.s("Keep screen on while running", "দৌড়ানোর সময় স্ক্রিন চালু রাখুন"), keep));

        col.addView(card, params(MATCH, WRAP, 0, 12));

        // about
        LinearLayout about = UI.card(this);
        about.addView(UI.tv(this, L.s("ABOUT", "পরিচিতি"), 12, UI.MUTED, true));
        about.addView(UI.tv(this, "RunTrack  v" + versionName(), 20, UI.ACCENT, true), params(WRAP, WRAP, 0, 8));
        about.addView(UI.tv(this, L.s("Developed by", "তৈরি করেছেন"), 13, UI.MUTED, false),
                params(WRAP, WRAP, 0, 14));
        about.addView(UI.tv(this, UI.DEV_NAME, 20, UI.TEXT, true), params(WRAP, WRAP, 0, 2));
        Button fb = UI.button(this, L.s("Open Facebook profile", "Facebook প্রোফাইল দেখুন"), true);
        fb.setOnClickListener(v -> openFacebook());
        about.addView(fb, params(MATCH, WRAP, 0, 14));
        about.addView(UI.tv(this,
                L.s("A free GPS run tracker.", "একটি বিনামূল্যের GPS রান ট্র্যাকার।"),
                13, UI.MUTED, false), params(WRAP, WRAP, 0, 12));
        col.addView(about, params(MATCH, WRAP, 0, 12));

        // clear history
        Button clear = UI.button(this, L.s("Clear run history", "ইতিহাস মুছে ফেলুন"), false);
        clear.setTextColor(UI.DANGER);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(L.s("Clear all runs?", "সব দৌড় মুছবেন?"))
                .setMessage(L.s("This cannot be undone.", "এটি আর ফেরত আনা যাবে না।"))
                .setPositiveButton(L.s("Clear", "মুছুন"), (d, w) -> {
                    Prefs.clearRuns();
                    Toast.makeText(this, L.s("History cleared", "ইতিহাস মুছে ফেলা হয়েছে"),
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(L.s("Cancel", "বাতিল"), null)
                .show());
        col.addView(clear, params(MATCH, WRAP, 0, 12));

        return scroll(col);
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "1.1";
        }
    }

    private View settingRow(String label, View control) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, UI.dp(this, 10), 0, UI.dp(this, 10));
        row.addView(UI.tv(this, label, 15, UI.TEXT, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(control, new LinearLayout.LayoutParams(WRAP, WRAP));
        return row;
    }

    private View stepper(final int[] value, final int min, final int max, final String suffix,
                         final IntSaver saver) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);

        final TextView val = UI.tv(this, value[0] + " " + suffix, 16, UI.TEXT, true);
        val.setGravity(Gravity.CENTER);
        Button minus = UI.button(this, "−", false);
        Button plus = UI.button(this, "+", false);
        minus.setPadding(UI.dp(this, 14), UI.dp(this, 6), UI.dp(this, 14), UI.dp(this, 6));
        plus.setPadding(UI.dp(this, 14), UI.dp(this, 6), UI.dp(this, 14), UI.dp(this, 6));

        minus.setOnClickListener(v -> {
            if (value[0] > min) {
                value[0]--;
                saver.save(value[0]);
                val.setText(value[0] + " " + suffix);
            }
        });
        plus.setOnClickListener(v -> {
            if (value[0] < max) {
                value[0]++;
                saver.save(value[0]);
                val.setText(value[0] + " " + suffix);
            }
        });

        box.addView(minus, new LinearLayout.LayoutParams(WRAP, WRAP));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(UI.dp(this, 72), WRAP);
        box.addView(val, vp);
        box.addView(plus, new LinearLayout.LayoutParams(WRAP, WRAP));
        return box;
    }
}
