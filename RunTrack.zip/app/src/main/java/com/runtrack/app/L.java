package com.runtrack.app;

/** Tiny translation helper: L.s("English", "বাংলা"). */
final class L {
    private L() {}

    static String s(String en, String bn) {
        return Prefs.bengali() ? bn : en;
    }
}
