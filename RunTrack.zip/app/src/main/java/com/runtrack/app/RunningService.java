package com.runtrack.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;

/** Foreground service that keeps GPS tracking alive while the screen is off. */
public class RunningService extends Service implements LocationListener {
    static final String ACTION_START = "com.runtrack.app.START";
    static final String ACTION_STOP = "com.runtrack.app.STOP";

    private static final String CHANNEL = "run_tracking";
    private static final int NOTIF_ID = 1;

    private LocationManager lm;
    private boolean registered;

    @Override
    public void onCreate() {
        super.onCreate();
        Prefs.init(getApplicationContext());
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_START.equals(action)) {
            begin();
        } else {
            shutdown();
        }
        return START_NOT_STICKY;
    }

    private void begin() {
        createChannel();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(NOTIF_ID, n);
        }
        if (!RunState.active) RunState.begin();

        if (registered) return;
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this);
            registered = true;
        } catch (SecurityException | IllegalArgumentException e) {
            RunState.reset();
            shutdown();
        }
    }

    private void shutdown() {
        if (lm != null && registered) {
            try {
                lm.removeUpdates(this);
            } catch (SecurityException e) {
                // nothing to do
            }
        }
        registered = false;
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (lm != null && registered) {
            try {
                lm.removeUpdates(this);
            } catch (SecurityException e) {
                // nothing to do
            }
            registered = false;
        }
        super.onDestroy();
    }

    private void createChannel() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "Run tracking", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String text = Fmt.dist(RunState.meters) + "  •  " + Fmt.clock(RunState.elapsedMs() / 1000);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("RunTrack")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_notification)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    @Override
    public void onLocationChanged(Location location) {
        RunState.onLocation(location);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification());
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
    }
}
