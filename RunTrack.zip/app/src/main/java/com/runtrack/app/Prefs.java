package com.runtrack.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** Settings and run history, stored in SharedPreferences. */
final class Prefs {
    private static SharedPreferences sp;

    private Prefs() {}

    static void init(Context c) {
        if (sp == null) {
            sp = c.getApplicationContext().getSharedPreferences("runtrack", Context.MODE_PRIVATE);
        }
    }

    // ---- settings ----

    static boolean bengali() { return sp.getBoolean("bn", true); }
    static void setBengali(boolean v) { sp.edit().putBoolean("bn", v).apply(); }

    static boolean miles() { return sp.getBoolean("miles", false); }
    static void setMiles(boolean v) { sp.edit().putBoolean("miles", v).apply(); }

    static int weightKg() { return sp.getInt("weight", 65); }
    static void setWeightKg(int v) { sp.edit().putInt("weight", v).apply(); }

    /** Weekly goal, in the unit currently selected (km or miles). */
    static int weeklyGoal() { return sp.getInt("goal", 20); }
    static void setWeeklyGoal(int v) { sp.edit().putInt("goal", v).apply(); }

    static boolean keepScreenOn() { return sp.getBoolean("keep_on", true); }
    static void setKeepScreenOn(boolean v) { sp.edit().putBoolean("keep_on", v).apply(); }

    // ---- history ----

    static List<Run> runs() {
        ArrayList<Run> list = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString("runs", "[]"));
            for (int i = 0; i < a.length(); i++) {
                list.add(Run.fromJson(a.getJSONObject(i)));
            }
        } catch (JSONException e) {
            // ignore broken data, start with an empty list
        }
        return list;
    }

    private static void saveRuns(List<Run> list) {
        JSONArray a = new JSONArray();
        for (Run r : list) {
            try {
                a.put(r.toJson());
            } catch (JSONException e) {
                // skip this run
            }
        }
        sp.edit().putString("runs", a.toString()).apply();
    }

    static void addRun(Run r) {
        List<Run> list = runs();
        list.add(0, r);
        saveRuns(list);
    }

    static void deleteRun(long id) {
        List<Run> list = runs();
        ArrayList<Run> keep = new ArrayList<>();
        for (Run r : list) {
            if (r.id != id) keep.add(r);
        }
        saveRuns(keep);
    }

    static void clearRuns() {
        sp.edit().putString("runs", "[]").apply();
    }
}
