package com.runtrack.app;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Colors, developer credit and small view-building helpers. */
final class UI {
    static final int BG = 0xFF0A0C0E;
    static final int CARD = 0xFF171C20;
    static final int LINE = 0xFF242B30;
    static final int ACCENT = 0xFFB8FF3A;
    static final int TEXT = 0xFFFFFFFF;
    static final int MUTED = 0xFF8A949C;
    static final int DANGER = 0xFFFF4D5E;

    static final String DEV_NAME = "MD HAMAYET HOSSAIN";
    static final String FB_URL = "https://www.facebook.com/share/1CQMntvP8J/";

    private UI() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(CARD, 16, c));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    static Button button(Context c, String label, boolean filled) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        if (filled) {
            b.setTextColor(BG);
            b.setBackground(round(ACCENT, 12, c));
        } else {
            b.setTextColor(TEXT);
            b.setBackground(round(LINE, 12, c));
        }
        b.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14));
        return b;
    }
}
