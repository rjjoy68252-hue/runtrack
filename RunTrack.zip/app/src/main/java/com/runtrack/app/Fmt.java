package com.runtrack.app;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Number / time formatting helpers. */
final class Fmt {
    private Fmt() {}

    static String clock(long sec) {
        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        long s = sec % 60;
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s);
    }

    static double unitMeters() {
        return Prefs.miles() ? 1609.344 : 1000.0;
    }

    static String unit() {
        return Prefs.miles() ? "mi" : "km";
    }

    static String distNum(double meters) {
        return String.format(Locale.US, "%.2f", meters / unitMeters());
    }

    static String dist(double meters) {
        return distNum(meters) + " " + unit();
    }

    /** Pace as mm:ss per km (or per mile). */
    static String pace(double meters, long sec) {
        if (meters < 50 || sec <= 0) return "--:--";
        long p = Math.round(sec / (meters / unitMeters()));
        return String.format(Locale.US, "%02d:%02d", p / 60, p % 60);
    }

    static String paceWithUnit(double meters, long sec) {
        return pace(meters, sec) + " /" + unit();
    }

    static int calories(double meters) {
        return (int) Math.round(Prefs.weightKg() * (meters / 1000.0) * 1.036);
    }

    static String date(long millis) {
        return new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(new Date(millis));
    }
}
