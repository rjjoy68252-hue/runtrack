package com.runtrack.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.View;

/** Round profile picture (or a placeholder when there is no photo). */
public class AvatarView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint icon = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix matrix = new Matrix();
    private Bitmap bmp;

    public AvatarView(Context c, Bitmap bmp) {
        super(c);
        this.bmp = bmp;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(UI.dp(c, 2));
        ring.setColor(UI.ACCENT);
        icon.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) / 2f - UI.dp(getContext(), 2);
        if (r <= 0) return;

        if (bmp != null) {
            BitmapShader shader = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            matrix.reset();
            matrix.setScale(2 * r / bmp.getWidth(), 2 * r / bmp.getHeight());
            matrix.postTranslate(cx - r, cy - r);
            shader.setLocalMatrix(matrix);
            fill.setShader(shader);
        } else {
            fill.setShader(null);
            fill.setColor(UI.LINE);
        }
        cv.drawCircle(cx, cy, r, fill);
        cv.drawCircle(cx, cy, r, ring);

        if (bmp == null) {
            icon.setTextSize(r * 1.0f);
            cv.drawText("👤", cx, cy + r * 0.33f, icon);
        }
    }
}
