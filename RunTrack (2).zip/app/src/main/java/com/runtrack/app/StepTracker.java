package com.runtrack.app;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/** Reads the phone's built-in step counter sensor. */
final class StepTracker implements SensorEventListener {
    private SensorManager sm;
    private boolean on;

    boolean available(Context c) {
        SensorManager m = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        return m != null && m.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null;
    }

    boolean start(Context c) {
        if (on) return true;
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) return false;
        Sensor sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (sensor == null) return false;
        on = sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI);
        return on;
    }

    void stop() {
        if (sm != null && on) {
            sm.unregisterListener(this);
        }
        on = false;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.values != null && event.values.length > 0) {
            Prefs.onStepSensor((long) event.values[0]);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
}
