package com.runtrack.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Profile photo, stored privately inside the app (one per account). */
final class Photo {
    private Photo() {}

    private static File file(Context c) {
        return new File(c.getFilesDir(), "profile_" + Accounts.prefsName(c) + ".jpg");
    }

    static Bitmap load(Context c) {
        File f = file(c);
        if (!f.exists()) return null;
        return BitmapFactory.decodeFile(f.getAbsolutePath());
    }

    static void remove(Context c) {
        File f = file(c);
        if (f.exists()) f.delete();
    }

    static boolean saveFromUri(Context c, Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in = c.getContentResolver().openInputStream(uri);
            if (in == null) return false;
            BitmapFactory.decodeStream(in, null, bounds);
            in.close();

            int sample = 1;
            int max = Math.max(bounds.outWidth, bounds.outHeight);
            while (max / sample > 900) sample *= 2;

            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            in = c.getContentResolver().openInputStream(uri);
            if (in == null) return false;
            Bitmap bm = BitmapFactory.decodeStream(in, null, o);
            in.close();
            if (bm == null) return false;

            int rotate = 0;
            in = c.getContentResolver().openInputStream(uri);
            if (in != null) {
                try {
                    ExifInterface exif = new ExifInterface(in);
                    int orient = exif.getAttributeInt(
                            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    if (orient == ExifInterface.ORIENTATION_ROTATE_90) rotate = 90;
                    else if (orient == ExifInterface.ORIENTATION_ROTATE_180) rotate = 180;
                    else if (orient == ExifInterface.ORIENTATION_ROTATE_270) rotate = 270;
                } catch (Exception ignored) {
                    // keep rotate = 0
                }
                in.close();
            }
            if (rotate != 0) {
                Matrix m = new Matrix();
                m.postRotate(rotate);
                bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
            }

            int side = Math.min(bm.getWidth(), bm.getHeight());
            Bitmap sq = Bitmap.createBitmap(bm, (bm.getWidth() - side) / 2,
                    (bm.getHeight() - side) / 2, side, side);
            Bitmap out = Bitmap.createScaledBitmap(sq, 360, 360, true);
            FileOutputStream fo = new FileOutputStream(file(c));
            out.compress(Bitmap.CompressFormat.JPEG, 90, fo);
            fo.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
