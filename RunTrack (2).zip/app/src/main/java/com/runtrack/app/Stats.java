package com.runtrack.app;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Calculations over the saved data: streaks, badges, chart series, daily totals. */
final class Stats {
    private Stats() {}

    static final class Badge {
        final String emoji, title, desc;
        final boolean earned;

        Badge(String emoji, String title, String desc, boolean earned) {
            this.emoji = emoji;
            this.title = title;
            this.desc = desc;
            this.earned = earned;
        }
    }

    // ---- daily totals ----

    /** Returns {meters, kcal, activeMinutes} for today, without counting steps and GPS twice. */
    static double[] today(List<Run> runs) {
        String key = Fmt.dayKey(System.currentTimeMillis());
        long steps = Prefs.stepsToday();
        double stepM = Fmt.stepsToMeters(steps);
        double stepCal = Fmt.stepCalories(steps);
        double stepMin = steps / 110.0;
        double footM = 0, footCal = 0, footMin = 0, cycM = 0, cycCal = 0, cycMin = 0;
        for (Run r : runs) {
            if (!Fmt.dayKey(r.id).equals(key)) continue;
            if (r.type == 2) {
                cycM += r.meters;
                cycCal += r.calories;
                cycMin += r.seconds / 60.0;
            } else {
                footM += r.meters;
                footCal += r.calories;
                footMin += r.seconds / 60.0;
            }
        }
        return new double[]{
                Math.max(stepM, footM) + cycM,
                Math.max(stepCal, footCal) + cycCal,
                Math.max(stepMin, footMin) + cycMin};
    }

    // ---- series for charts, oldest first ----

    static float[] series(String type, int n) {
        float[] v = new float[n];
        for (int i = 0; i < n; i++) {
            v[i] = Prefs.dayGet(type, Fmt.dayKeyAgo(n - 1 - i), 0f);
        }
        return v;
    }

    /** Workout distance per day in the selected unit. */
    static float[] workoutSeries(List<Run> runs, int n) {
        float[] v = new float[n];
        for (int i = 0; i < n; i++) {
            String key = Fmt.dayKeyAgo(n - 1 - i);
            double m = 0;
            for (Run r : runs) {
                if (Fmt.dayKey(r.id).equals(key)) m += r.meters;
            }
            v[i] = (float) (m / Fmt.unitMeters());
        }
        return v;
    }

    static String[] labels(int n) {
        String[] l = new String[n];
        for (int i = 0; i < n; i++) {
            l[i] = Fmt.dayShort(n - 1 - i);
        }
        return l;
    }

    /** Returns {latest, previous, daysAgoOfLatest}; -1 where nothing is logged. */
    static float[] recent(String type, int maxDays) {
        float latest = -1, prev = -1;
        int ago = -1;
        for (int i = 0; i < maxDays; i++) {
            float v = Prefs.dayGet(type, Fmt.dayKeyAgo(i), -1f);
            if (v >= 0) {
                if (latest < 0) {
                    latest = v;
                    ago = i;
                } else {
                    prev = v;
                    break;
                }
            }
        }
        return new float[]{latest, prev, ago};
    }

    // ---- streak ----

    private static Set<String> workoutDays(List<Run> runs) {
        HashSet<String> set = new HashSet<>();
        for (Run r : runs) set.add(Fmt.dayKey(r.id));
        return set;
    }

    private static boolean activeDay(String key, Set<String> workoutDays) {
        return Prefs.dayGet("steps", key, 0f) >= Prefs.stepGoal() || workoutDays.contains(key);
    }

    /** Days in a row with the step goal reached or a workout done (today may still be open). */
    static int streak(List<Run> runs) {
        Set<String> wd = workoutDays(runs);
        int i = activeDay(Fmt.dayKeyAgo(0), wd) ? 0 : 1;
        int count = 0;
        while (i < 400 && activeDay(Fmt.dayKeyAgo(i), wd)) {
            count++;
            i++;
        }
        if (count > Prefs.bestStreak()) Prefs.setBestStreak(count);
        return count;
    }

    // ---- badges ----

    private static Badge badge(String id, String emoji, String titleEn, String titleBn,
                               String descEn, String descBn, boolean cond) {
        boolean earned = cond || Prefs.badge(id);
        if (cond && !Prefs.badge(id)) Prefs.setBadge(id);
        return new Badge(emoji, L.s(titleEn, titleBn), L.s(descEn, descBn), earned);
    }

    static List<Badge> badges(List<Run> runs, int streak) {
        double total = 0, longest = 0;
        for (Run r : runs) {
            total += r.meters;
            if (r.meters > longest) longest = r.meters;
        }
        float maxSteps = 0;
        boolean waterHit = false, sleepHit = false;
        for (int i = 0; i < 60; i++) {
            String k = Fmt.dayKeyAgo(i);
            maxSteps = Math.max(maxSteps, Prefs.dayGet("steps", k, 0f));
            if (Prefs.dayGet("water", k, 0f) >= Prefs.waterGoal()) waterHit = true;
            if (Prefs.dayGet("sleep", k, 0f) >= Prefs.sleepGoalHours() * 60f) sleepHit = true;
        }
        int best = Math.max(streak, Prefs.bestStreak());

        ArrayList<Badge> list = new ArrayList<>();
        list.add(badge("first", "🏅", "First step", "প্রথম ধাপ",
                "Finish your first workout", "প্রথম ওয়ার্কআউট শেষ করুন", !runs.isEmpty()));
        list.add(badge("run5k", "🎯", "5K club", "৫ কিমি ক্লাব",
                "5 km in one workout", "একবারে ৫ কিমি", longest >= 5000));
        list.add(badge("km10", "🥉", "10 km total", "মোট ১০ কিমি",
                "10 km of workouts in total", "সব মিলিয়ে ১০ কিমি", total >= 10000));
        list.add(badge("km50", "🥈", "50 km total", "মোট ৫০ কিমি",
                "50 km of workouts in total", "সব মিলিয়ে ৫০ কিমি", total >= 50000));
        list.add(badge("km100", "🥇", "100 km total", "মোট ১০০ কিমি",
                "100 km of workouts in total", "সব মিলিয়ে ১০০ কিমি", total >= 100000));
        list.add(badge("steps10k", "👟", "10K steps", "১০ হাজার স্টেপ",
                "10,000 steps in a day", "এক দিনে ১০,০০০ স্টেপ", maxSteps >= 10000));
        list.add(badge("streak7", "🔥", "7-day streak", "৭ দিনের স্ট্রিক",
                "Be active 7 days in a row", "টানা ৭ দিন সক্রিয় থাকুন", best >= 7));
        list.add(badge("water", "💧", "Hydration hero", "পানি যোদ্ধা",
                "Reach your daily water goal", "দৈনিক পানির লক্ষ্য পূরণ করুন", waterHit));
        list.add(badge("sleep", "🌙", "Sleep champ", "ঘুম চ্যাম্পিয়ন",
                "Reach your sleep goal", "ঘুমের লক্ষ্য পূরণ করুন", sleepHit));
        return list;
    }
}
