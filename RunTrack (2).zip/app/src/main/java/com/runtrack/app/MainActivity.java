package com.runtrack.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/** Hosts the five tabs: Home, Workout, Health, Progress, Settings. */
public class MainActivity extends Activity {

    static final int REQ_LOCATION = 11;
    static final int REQ_ACTIVITY = 12;
    static final int REQ_NOTIF = 13;
    static final int REQ_PHOTO = 14;

    interface NumCallback {
        void onValue(double v);
    }

    interface TextCallback {
        void onText(String s);
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StepTracker stepTracker = new StepTracker();
    private FrameLayout content;
    private final TextView[] navIcon = new TextView[5];
    private final TextView[] navLabel = new TextView[5];
    private int tab = 0;
    private Screen current;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (current != null) current.tick();
            handler.postDelayed(this, 1000);
        }
    };

    // ------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Prefs.init(this);
        UI.applyTheme();
        if (Prefs.waterRemind()) WaterReceiver.schedule(this);
        buildAll();

        if (!hasActivityPermission() && !Prefs.askedActivity()) {
            Prefs.setAskedActivity(true);
            requestActivity();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startSteps();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
        stepTracker.stop();
    }

    // ------------------------------------------------------------------
    // frame: top bar, content, bottom nav, developer footer
    // ------------------------------------------------------------------

    /** Rebuilds the whole window (used after language or color changes). */
    void rebuildAll() {
        buildAll();
    }

    void applyThemeAndRebuild() {
        UI.applyTheme();
        buildAll();
    }

    private void buildAll() {
        getWindow().getDecorView().setBackgroundColor(UI.BG);
        getWindow().setStatusBarColor(UI.BG);
        getWindow().setNavigationBarColor(UI.BG);
        int flags = 0;
        if (Prefs.lightMode()) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        root.setFitsSystemWindows(true);

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(UI.MATCH, 0, 1f));
        root.addView(buildNav(), new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));
        root.addView(buildFooter(), new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));

        setContentView(root);
        showTab(tab);
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int p = UI.dp(this, 16);
        bar.setPadding(p, UI.dp(this, 8), p, UI.dp(this, 6));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(UI.tv(this, "RUNTRACK", 22, UI.TEXT, true));
        titles.addView(UI.tv(this, L.s("HEALTH  •  FITNESS", "স্বাস্থ্য  •  ফিটনেস"), 10, UI.GOLD, true));
        bar.addView(titles, new LinearLayout.LayoutParams(0, UI.WRAP, 1f));

        TextView lang = UI.tv(this, "বাংলা / EN", 12, UI.TEXT, true);
        lang.setBackground(UI.round(UI.LINE, 12, this));
        lang.setPadding(UI.dp(this, 14), UI.dp(this, 8), UI.dp(this, 14), UI.dp(this, 8));
        lang.setOnClickListener(v -> {
            Prefs.setBengali(!Prefs.bengali());
            buildAll();
        });
        bar.addView(lang, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        return bar;
    }

    private View buildNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(UI.blend(UI.BG, UI.CARD_TOP, 0.55f));

        String[] icons = {"🏠", "🏃", "❤️", "📈", "⚙️"};
        String[] labels = {
                L.s("Home", "হোম"),
                L.s("Workout", "ওয়ার্কআউট"),
                L.s("Health", "স্বাস্থ্য"),
                L.s("Progress", "অগ্রগতি"),
                L.s("Settings", "সেটিংস")
        };
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(0, UI.dp(this, 8), 0, UI.dp(this, 8));
            navIcon[i] = UI.tv(this, icons[i], 19, UI.MUTED, false);
            navLabel[i] = UI.tv(this, labels[i], 10, UI.MUTED, true);
            item.addView(navIcon[i], new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
            item.addView(navLabel[i], new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
            item.setOnClickListener(v -> showTab(idx));
            nav.addView(item, new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        }
        return nav;
    }

    /** Developer credit: shown at the very bottom of every screen. */
    private View buildFooter() {
        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.CENTER);
        footer.setBackgroundColor(UI.blend(UI.BG, UI.STROKE, 0.4f));
        footer.setPadding(UI.dp(this, 12), UI.dp(this, 8), UI.dp(this, 12), UI.dp(this, 8));

        TextView name = UI.tv(this,
                L.s("Developed by ", "তৈরি করেছেন ") + UI.DEV_NAME, 11, UI.MUTED, false);
        TextView fb = UI.tv(this, "  •  Facebook", 11, UI.ACCENT, true);
        footer.addView(name, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        footer.addView(fb, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        footer.setOnClickListener(v -> openFacebook());
        return footer;
    }

    void openFacebook() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(UI.FB_URL)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, UI.FB_URL, Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------------
    // tabs
    // ------------------------------------------------------------------

    void go(int t) {
        showTab(t);
    }

    /** Rebuilds the visible tab (after data or settings changed). */
    void refresh() {
        showTab(tab);
    }

    private void showTab(int t) {
        tab = t;
        content.removeAllViews();
        switch (t) {
            case 0:
                current = new HomeScreen(this);
                break;
            case 1:
                current = new WorkoutScreen(this);
                break;
            case 2:
                current = new HealthScreen(this);
                break;
            case 3:
                current = new ProgressScreen(this);
                break;
            default:
                current = new SettingsScreen(this);
                break;
        }
        content.addView(current.build(), new FrameLayout.LayoutParams(UI.MATCH, UI.MATCH));

        for (int i = 0; i < 5; i++) {
            boolean sel = i == t;
            navLabel[i].setTextColor(sel ? UI.ACCENT : UI.MUTED);
            navIcon[i].setAlpha(sel ? 1f : 0.45f);
        }
    }

    // ------------------------------------------------------------------
    // permissions and sensors
    // ------------------------------------------------------------------

    boolean hasActivityPermission() {
        return Build.VERSION.SDK_INT < 29
                || checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)
                == PackageManager.PERMISSION_GRANTED;
    }

    boolean stepSensorPresent() {
        return stepTracker.available(this);
    }

    private void startSteps() {
        if (hasActivityPermission()) {
            stepTracker.start(this);
        }
    }

    void requestActivity() {
        ArrayList<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 29) p.add(Manifest.permission.ACTIVITY_RECOGNITION);
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!p.isEmpty()) {
            requestPermissions(p.toArray(new String[0]), REQ_ACTIVITY);
        }
    }

    void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }

    void requestLocation() {
        ArrayList<String> p = new ArrayList<>();
        p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        p.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(p.toArray(new String[0]), REQ_LOCATION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                if (current instanceof WorkoutScreen) {
                    ((WorkoutScreen) current).startRunFlow();
                }
            } else {
                toast(L.s("Please allow Precise location", "অনুগ্রহ করে Precise location অনুমতি দিন"));
            }
        } else if (requestCode == REQ_ACTIVITY) {
            startSteps();
            refresh();
        }
    }

    // ------------------------------------------------------------------
    // small helpers for screens
    // ------------------------------------------------------------------

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "3.0";
        }
    }

    // ------------------------------------------------------------------
    // profile photo and accounts
    // ------------------------------------------------------------------

    void pickPhoto() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        startActivityForResult(
                Intent.createChooser(i, L.s("Choose photo", "ছবি বাছুন")), REQ_PHOTO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PHOTO && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            if (Photo.saveFromUri(this, data.getData())) {
                refresh();
            } else {
                toast(L.s("Could not use that photo", "এই ছবিটা ব্যবহার করা গেল না"));
            }
        }
    }

    /** Loads the data of the now-active account and redraws everything. */
    private void accountChanged() {
        Prefs.reload(this);
        UI.applyTheme();
        if (Prefs.waterRemind()) {
            WaterReceiver.schedule(this);
        } else {
            WaterReceiver.cancel(this);
        }
        rebuildAll();
    }

    void signOut() {
        if (RunState.active) {
            toast(L.s("Finish your workout first", "আগে ওয়ার্কআউট শেষ করুন"));
            return;
        }
        Accounts.signOut(this);
        accountChanged();
        toast(L.s("Signed out. Your data is kept on this phone.",
                "সাইন আউট হয়েছে। ডেটা এই ফোনেই আছে।"));
    }

    void showAccountSwitcher() {
        if (RunState.active) {
            toast(L.s("Finish your workout first", "আগে ওয়ার্কআউট শেষ করুন"));
            return;
        }
        final ArrayList<String> emails = new ArrayList<>(Accounts.list(this));
        int n = emails.size();
        CharSequence[] items = new CharSequence[n + 2];
        for (int i = 0; i < n; i++) items[i] = emails.get(i);
        items[n] = L.s("Guest (no account)", "অতিথি (অ্যাকাউন্ট ছাড়া)");
        items[n + 1] = L.s("+ Add another Gmail", "+ আরেকটি Gmail যোগ করুন");
        final int count = n;
        new AlertDialog.Builder(this)
                .setTitle(L.s("Accounts", "অ্যাকাউন্ট"))
                .setItems(items, (d, which) -> {
                    if (which < count) {
                        Accounts.switchTo(this, emails.get(which));
                        accountChanged();
                    } else if (which == count) {
                        Accounts.signOut(this);
                        accountChanged();
                    } else {
                        promptSignIn();
                    }
                })
                .show();
    }

    /** Asks for an email (and a name) and signs in on this phone. */
    void promptSignIn() {
        if (RunState.active) {
            toast(L.s("Finish your workout first", "আগে ওয়ার্কআউট শেষ করুন"));
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 20);
        box.setPadding(p, UI.dp(this, 8), p, 0);

        final EditText email = new EditText(this);
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        email.setHint("name@gmail.com");
        email.setSingleLine(true);
        box.addView(email, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));

        final EditText name = new EditText(this);
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        name.setHint(L.s("Your name", "আপনার নাম"));
        name.setSingleLine(true);
        box.addView(name, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));

        TextView note = UI.tv(this, L.s(
                "Saved on this phone only. Not verified by Google.",
                "শুধু এই ফোনে সেভ থাকে। Google যাচাই করে না।"), 12, UI.MUTED, false);
        box.addView(note, UI.lp(this, UI.WRAP, UI.WRAP, 0, 10));

        new AlertDialog.Builder(this)
                .setTitle(L.s("Sign in with Gmail", "Gmail দিয়ে সাইন ইন"))
                .setView(box)
                .setPositiveButton(L.s("Sign in", "সাইন ইন"), (d, w) -> {
                    String e = email.getText().toString().trim();
                    if (!Accounts.validEmail(e)) {
                        toast(L.s("Please enter a valid email", "সঠিক ইমেইল লিখুন"));
                        return;
                    }
                    Accounts.signIn(this, e);
                    Prefs.reload(this);
                    String nm = name.getText().toString().trim();
                    if (!nm.isEmpty() && Prefs.name().isEmpty()) Prefs.setName(nm);
                    accountChanged();
                })
                .setNegativeButton(L.s("Cancel", "বাতিল"), null)
                .show();
    }

    void promptNumber(String title, String hint, boolean decimal, final NumCallback cb) {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER
                | (decimal ? InputType.TYPE_NUMBER_FLAG_DECIMAL : 0));
        et.setHint(hint);
        et.setSingleLine(true);
        FrameLayout box = new FrameLayout(this);
        int p = UI.dp(this, 20);
        box.setPadding(p, UI.dp(this, 8), p, 0);
        box.addView(et, new FrameLayout.LayoutParams(UI.MATCH, UI.WRAP));

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("OK", (d, w) -> {
                    try {
                        cb.onValue(Double.parseDouble(et.getText().toString().trim()));
                    } catch (NumberFormatException e) {
                        toast(L.s("Please enter a number", "অনুগ্রহ করে সংখ্যা লিখুন"));
                    }
                })
                .setNegativeButton(L.s("Cancel", "বাতিল"), null)
                .show();
    }

    void promptText(String title, String initial, final TextCallback cb) {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        et.setText(initial);
        et.setSingleLine(true);
        FrameLayout box = new FrameLayout(this);
        int p = UI.dp(this, 20);
        box.setPadding(p, UI.dp(this, 8), p, 0);
        box.addView(et, new FrameLayout.LayoutParams(UI.MATCH, UI.WRAP));

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("OK", (d, w) -> cb.onText(et.getText().toString()))
                .setNegativeButton(L.s("Cancel", "বাতিল"), null)
                .show();
    }
}
