package com.runtrack.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Circular progress ring with two lines of text in the middle. */
public class RingView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint big = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();

    private float progress;
    private String bigText = "";
    private String smallText = "";

    public RingView(Context c) {
        super(c);
        float stroke = UI.dp(c, 11);

        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(stroke);
        track.setColor(UI.LINE);

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(stroke);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setColor(UI.ACCENT);

        big.setTextAlign(Paint.Align.CENTER);
        big.setTypeface(Typeface.DEFAULT_BOLD);
        big.setColor(UI.TEXT);

        small.setTextAlign(Paint.Align.CENTER);
        small.setColor(UI.MUTED);
        small.setTextSize(UI.dp(c, 11));
    }

    void set(float p, int color, String bigText, String smallText) {
        this.progress = Math.max(0f, Math.min(1f, p));
        this.bigText = bigText;
        this.smallText = smallText;
        arc.setColor(color);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float w = getWidth();
        float h = getHeight();
        float size = Math.min(w, h);
        float half = arc.getStrokeWidth() / 2f;
        box.set((w - size) / 2f + half, (h - size) / 2f + half,
                (w + size) / 2f - half, (h + size) / 2f - half);

        cv.drawArc(box, -90f, 360f, false, track);
        if (progress > 0f) {
            cv.drawArc(box, -90f, 360f * progress, false, arc);
        }

        big.setTextSize(UI.dp(getContext(), bigText.length() > 5 ? 22 : 28));
        float cy = h / 2f;
        cv.drawText(bigText, w / 2f, cy - UI.dp(getContext(), 1), big);
        cv.drawText(smallText, w / 2f, cy + UI.dp(getContext(), 18), small);
    }
}
