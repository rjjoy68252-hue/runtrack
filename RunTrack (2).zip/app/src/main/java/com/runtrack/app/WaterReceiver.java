package com.runtrack.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

/** Shows a "drink water" reminder every couple of hours (08:00 - 22:00). */
public class WaterReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "water_reminder";
    private static final int NOTIF_ID = 2;

    private static PendingIntent pending(Context c) {
        Intent i = new Intent(c, WaterReceiver.class);
        return PendingIntent.getBroadcast(
                c, 7, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long interval = AlarmManager.INTERVAL_HOUR * 2;
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + interval, interval, pending(c));
    }

    static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pending(c));
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Prefs.init(context);
        if (!Prefs.waterRemind()) return;

        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 8 || hour >= 22) return;

        float ml = Prefs.dayGet("water", Fmt.dayKey(System.currentTimeMillis()), 0f);
        int goal = Prefs.waterGoal();
        if (ml >= goal) return;

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Water reminder", NotificationManager.IMPORTANCE_DEFAULT));

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                context, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        String text = Math.round(ml) + " / " + goal + " ml";
        Notification n = new Notification.Builder(context, CHANNEL)
                .setContentTitle(L.s("Time to drink water", "পানি পান করার সময়"))
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_water)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify(NOTIF_ID, n);
    }
}
