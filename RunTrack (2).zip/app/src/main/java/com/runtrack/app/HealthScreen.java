package com.runtrack.app;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Daily health logs: water, sleep, weight / BMI and heart rate. */
final class HealthScreen extends Screen {
    private LinearLayout col;

    HealthScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        col = UI.page(a);
        fill();
        return UI.scroll(a, col);
    }

    private void redraw() {
        col.removeAllViews();
        fill();
    }

    private void fill() {
        col.addView(UI.tv(a, L.s("Health", "স্বাস্থ্য"), 24, UI.TEXT, true));
        addWater();
        addSleep();
        addWeight();
        addHeart();
    }

    private String today() {
        return Fmt.dayKey(System.currentTimeMillis());
    }

    private LinearLayout.LayoutParams weightParams(boolean first) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        if (!first) p.leftMargin = UI.dp(a, 8);
        return p;
    }

    // ------------------------------------------------------------------
    // water
    // ------------------------------------------------------------------

    private void addMl(int amt) {
        float cur = Prefs.dayGet("water", today(), 0f);
        Prefs.dayPut("water", today(), cur + amt);
        Prefs.setLastWater(amt);
        redraw();
    }

    private void addWater() {
        float ml = Prefs.dayGet("water", today(), 0f);
        int goal = Math.max(1, Prefs.waterGoal());

        LinearLayout card = UI.tintedCard(a, UI.BLUE);
        card.addView(UI.tv(a, "💧 " + L.s("WATER", "পানি"), 12, UI.BLUE, true));

        LinearLayout top = UI.row(a);
        RingView ring = new RingView(a);
        ring.set(ml / goal, UI.BLUE, String.valueOf(Math.round(ml)), "/ " + goal + " ml");
        top.addView(ring, new LinearLayout.LayoutParams(UI.dp(a, 120), UI.dp(a, 120)));

        LinearLayout info = new LinearLayout(a);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(UI.tv(a, Math.round(100f * ml / goal) + "%", 28, UI.TEXT, true));
        int left = Math.max(0, goal - Math.round(ml));
        String msg = left > 0
                ? L.s(left + " ml to go", "আরও " + left + " ml বাকি")
                : L.s("Goal reached! 🎉", "লক্ষ্য পূরণ! 🎉");
        info.addView(UI.tv(a, msg, 13, UI.MUTED, false));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        ip.leftMargin = UI.dp(a, 16);
        top.addView(info, ip);
        card.addView(top, UI.lp(a, UI.MATCH, UI.WRAP, 0, 8));

        LinearLayout quick = new LinearLayout(a);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        int[] amounts = {200, 300, 500};
        for (int i = 0; i < amounts.length; i++) {
            final int amt = amounts[i];
            Button b = UI.button(a, "+" + amt, true);
            b.setOnClickListener(x -> addMl(amt));
            quick.addView(b, weightParams(i == 0));
        }
        card.addView(quick, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        LinearLayout more = new LinearLayout(a);
        more.setOrientation(LinearLayout.HORIZONTAL);
        Button custom = UI.button(a, L.s("Custom", "অন্য পরিমাণ"), false);
        custom.setOnClickListener(x -> a.promptNumber(
                L.s("Amount (ml)", "পরিমাণ (ml)"), "ml", false, v -> {
                    if (v > 0 && v <= 5000) addMl((int) Math.round(v));
                }));
        Button undo = UI.button(a, L.s("Undo", "ফেরত"), false);
        undo.setOnClickListener(x -> {
            int last = Prefs.lastWater();
            if (last > 0) {
                float cur = Prefs.dayGet("water", today(), 0f);
                Prefs.dayPut("water", today(), Math.max(0f, cur - last));
                Prefs.setLastWater(0);
                redraw();
            }
        });
        Button reset = UI.button(a, L.s("Reset", "রিসেট"), false);
        reset.setOnClickListener(x -> {
            Prefs.dayRemove("water", today());
            Prefs.setLastWater(0);
            redraw();
        });
        more.addView(custom, weightParams(true));
        more.addView(undo, weightParams(false));
        more.addView(reset, weightParams(false));
        card.addView(more, UI.lp(a, UI.MATCH, UI.WRAP, 0, 8));

        col.addView(card, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
    }

    // ------------------------------------------------------------------
    // sleep
    // ------------------------------------------------------------------

    private void addSleep() {
        float min = Prefs.dayGet("sleep", today(), -1f);
        int goalH = Prefs.sleepGoalHours();

        LinearLayout card = UI.tintedCard(a, UI.PURPLE);
        card.addView(UI.tv(a, "😴 " + L.s("SLEEP", "ঘুম"), 12, UI.PURPLE, true));
        card.addView(UI.tv(a, min < 0 ? "--" : Fmt.hm(Math.round(min)), 28, UI.TEXT, true),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));
        card.addView(UI.tv(a, L.s("Last night  •  goal ", "গত রাত  •  লক্ষ্য ") + goalH + L.s("h", " ঘ"),
                12, UI.MUTED, false));
        card.addView(UI.progressBar(a, min < 0 ? 0f : min / (goalH * 60f), UI.PURPLE),
                UI.lp(a, UI.MATCH, UI.dp(a, 10), 0, 10));

        float[] hours = Stats.series("sleep", 7);
        for (int i = 0; i < hours.length; i++) hours[i] = hours[i] / 60f;
        BarChartView chart = new BarChartView(a);
        chart.set(hours, Stats.labels(7), UI.PURPLE, goalH);
        card.addView(chart, UI.lp(a, UI.MATCH, UI.dp(a, 130), 0, 12));

        Button log = UI.button(a, L.s("Log sleep", "ঘুম লিখুন"), true);
        log.setOnClickListener(x -> a.promptNumber(
                L.s("Hours slept (e.g. 7.5)", "কত ঘণ্টা ঘুমিয়েছেন (যেমন ৭.৫)"), "7.5", true, v -> {
                    if (v >= 0 && v <= 24) {
                        Prefs.dayPut("sleep", today(), Math.round(v * 60));
                        redraw();
                    }
                }));
        card.addView(log, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        col.addView(card, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
    }

    // ------------------------------------------------------------------
    // weight / BMI
    // ------------------------------------------------------------------

    private void addWeight() {
        float[] r = Stats.recent("weight", 365);
        float latest = r[0];
        float prev = r[1];

        LinearLayout card = UI.tintedCard(a, UI.GOLD);
        card.addView(UI.tv(a, "⚖️ " + L.s("WEIGHT & BMI", "ওজন ও BMI"), 12, UI.GOLD, true));
        card.addView(UI.tv(a, latest < 0 ? "--" : String.format(Locale.US, "%.1f kg", latest), 28,
                UI.TEXT, true), UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));

        if (latest >= 0) {
            if (prev >= 0) {
                float diff = latest - prev;
                String sign = diff > 0 ? "+" : "";
                card.addView(UI.tv(a, String.format(Locale.US, "%s%.1f kg ", sign, diff)
                        + L.s("since last entry", "আগের এন্ট্রির চেয়ে"), 12, UI.MUTED, false));
            }
            float hM = Prefs.heightCm() / 100f;
            float bmi = latest / (hM * hM);
            String cat;
            int catColor;
            if (bmi < 18.5f) {
                cat = L.s("Underweight", "কম ওজন");
                catColor = UI.BLUE;
            } else if (bmi < 25f) {
                cat = L.s("Normal", "স্বাভাবিক");
                catColor = UI.ACCENT;
            } else if (bmi < 30f) {
                cat = L.s("Overweight", "বেশি ওজন");
                catColor = UI.ORANGE;
            } else {
                cat = L.s("Obese range", "স্থূলতার সীমা");
                catColor = UI.RED;
            }
            LinearLayout b = UI.row(a);
            b.addView(UI.tv(a, "BMI " + String.format(Locale.US, "%.1f", bmi), 18, UI.TEXT, true));
            TextView catText = UI.tv(a, "  " + cat, 15, catColor, true);
            b.addView(catText);
            card.addView(b, UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));
            card.addView(UI.tv(a, L.s("Height used: ", "উচ্চতা: ") + Prefs.heightCm()
                    + " cm  (" + L.s("change in Settings", "সেটিংসে বদলান") + ")", 11, UI.MUTED, false));
        }

        Button log = UI.button(a, L.s("Log weight", "ওজন লিখুন"), true);
        log.setOnClickListener(x -> a.promptNumber(
                L.s("Weight in kg", "ওজন (কেজি)"), "65.5", true, v -> {
                    if (v >= 20 && v <= 300) {
                        Prefs.dayPut("weight", today(), (float) v);
                        Prefs.setWeightKg((int) Math.round(v));
                        redraw();
                    }
                }));
        card.addView(log, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        col.addView(card, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
    }

    // ------------------------------------------------------------------
    // heart rate (manual)
    // ------------------------------------------------------------------

    private void addHeart() {
        float[] r = Stats.recent("hr", 60);

        LinearLayout card = UI.tintedCard(a, UI.RED);
        card.addView(UI.tv(a, "❤️ " + L.s("HEART RATE", "হার্ট রেট"), 12, UI.RED, true));
        card.addView(UI.tv(a, r[0] < 0 ? "--" : Math.round(r[0]) + " bpm", 28, UI.TEXT, true),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));

        String when;
        int ago = Math.round(r[2]);
        if (r[0] < 0) {
            when = L.s("No reading yet", "এখনও কোনো রিডিং নেই");
        } else if (ago == 0) {
            when = L.s("Today", "আজ");
        } else if (ago == 1) {
            when = L.s("Yesterday", "গতকাল");
        } else {
            when = L.s(ago + " days ago", ago + " দিন আগে");
        }
        card.addView(UI.tv(a, when + "  •  " + L.s("typical resting 60–100 bpm", "স্বাভাবিক বিশ্রামে ৬০–১০০ bpm"),
                12, UI.MUTED, false));

        BarChartView chart = new BarChartView(a);
        chart.set(Stats.series("hr", 7), Stats.labels(7), UI.RED, -1f);
        card.addView(chart, UI.lp(a, UI.MATCH, UI.dp(a, 130), 0, 12));

        Button log = UI.button(a, L.s("Log heart rate", "হার্ট রেট লিখুন"), true);
        log.setOnClickListener(x -> a.promptNumber(
                L.s("Beats per minute", "প্রতি মিনিটে স্পন্দন"), "72", false, v -> {
                    if (v >= 30 && v <= 220) {
                        Prefs.dayPut("hr", today(), (float) Math.round(v));
                        redraw();
                    }
                }));
        card.addView(log, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        card.addView(UI.tv(a, L.s("Manual entry. This app is not a medical device.",
                "হাতে লেখা রিডিং। এই অ্যাপ কোনো মেডিকেল ডিভাইস নয়।"), 11, UI.MUTED, false),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 8));

        col.addView(card, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
    }
}
