package com.runtrack.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Daily task list shown on the Home screen. */
final class Tasks {
    private Tasks() {}

    static final int MANUAL = 0;       // custom task, ticked by hand
    static final int WATER = 1;        // done when the water goal is reached
    static final int STEPS = 2;        // done when the step goal is reached
    static final int WORKOUT = 3;      // done when a workout was saved today
    static final int MORNING_WALK = 4; // manual, built-in title

    static final class Task {
        final long id;
        final int kind;
        final String title;

        Task(long id, int kind, String title) {
            this.id = id;
            this.kind = kind;
            this.title = title;
        }

        boolean auto() {
            return kind == WATER || kind == STEPS || kind == WORKOUT;
        }
    }

    static List<Task> defaults() {
        ArrayList<Task> l = new ArrayList<>();
        l.add(new Task(1, MORNING_WALK, ""));
        l.add(new Task(2, WATER, ""));
        l.add(new Task(3, WORKOUT, ""));
        return l;
    }

    static List<Task> list() {
        String s = Prefs.str("tasks", null);
        if (s == null) return defaults();
        ArrayList<Task> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                l.add(new Task(o.optLong("i"), o.optInt("k"), o.optString("t", "")));
            }
        } catch (JSONException e) {
            return defaults();
        }
        return l;
    }

    private static void save(List<Task> l) {
        JSONArray a = new JSONArray();
        for (Task t : l) {
            try {
                JSONObject o = new JSONObject();
                o.put("i", t.id);
                o.put("k", t.kind);
                o.put("t", t.title);
                a.put(o);
            } catch (JSONException e) {
                // skip
            }
        }
        Prefs.putStr("tasks", a.toString());
    }

    static void add(String title) {
        List<Task> l = list();
        l.add(new Task(System.currentTimeMillis(), MANUAL, title));
        save(l);
    }

    static void remove(long id) {
        ArrayList<Task> keep = new ArrayList<>();
        for (Task t : list()) {
            if (t.id != id) keep.add(t);
        }
        save(keep);
    }

    static void reset() {
        save(defaults());
    }

    static String title(Task t) {
        switch (t.kind) {
            case WATER:
                return L.s("Drink " + String.format(Locale.US, "%.1f", Prefs.waterGoal() / 1000.0) + " L water",
                        String.format(Locale.US, "%.1f", Prefs.waterGoal() / 1000.0) + " লিটার পানি পান করুন");
            case STEPS:
                return L.s("Reach " + Fmt.num(Prefs.stepGoal()) + " steps",
                        Fmt.num(Prefs.stepGoal()) + " স্টেপ পূর্ণ করুন");
            case WORKOUT:
                return L.s("Do a workout", "একটি ওয়ার্কআউট করুন");
            case MORNING_WALK:
                return L.s("Morning walk", "সকালে হাঁটা");
            default:
                return t.title;
        }
    }

    private static String flagKey(Task t) {
        return "tc_" + Fmt.dayKey(System.currentTimeMillis()) + "_" + t.id;
    }

    static boolean done(Task t, List<Run> runs) {
        String today = Fmt.dayKey(System.currentTimeMillis());
        switch (t.kind) {
            case WATER:
                return Prefs.dayGet("water", today, 0f) >= Prefs.waterGoal();
            case STEPS:
                return Prefs.stepsToday() >= Prefs.stepGoal();
            case WORKOUT:
                for (Run r : runs) {
                    if (Fmt.dayKey(r.id).equals(today)) return true;
                }
                return false;
            default:
                return Prefs.flag(flagKey(t));
        }
    }

    static void toggle(Task t) {
        if (t.auto()) return;
        Prefs.setFlag(flagKey(t), !Prefs.flag(flagKey(t)));
    }
}
