package com.runtrack.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Accounts that live on this phone. Each account has its own settings, health logs and
 * workout history. Nothing here is verified with Google and nothing leaves the phone.
 * "Guest" (no email) keeps using the original data file.
 */
final class Accounts {
    private Accounts() {}

    private static SharedPreferences reg(Context c) {
        return c.getApplicationContext().getSharedPreferences("accounts", Context.MODE_PRIVATE);
    }

    /** Active account email, or "" for guest. */
    static String active(Context c) {
        return reg(c).getString("active", "");
    }

    static boolean signedIn(Context c) {
        return !active(c).isEmpty();
    }

    static String prefsName(Context c) {
        String e = active(c);
        if (e.isEmpty()) return "runtrack";
        return "runtrack_" + e.toLowerCase(Locale.US).replaceAll("[^a-z0-9]", "_");
    }

    static List<String> list(Context c) {
        ArrayList<String> out = new ArrayList<>();
        String s = reg(c).getString("list", "");
        if (!s.isEmpty()) {
            for (String e : s.split("\n")) {
                if (!e.isEmpty()) out.add(e);
            }
        }
        return out;
    }

    static boolean validEmail(String e) {
        return e != null && e.matches("^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}$");
    }

    /** Adds (if new) and activates the account. */
    static void signIn(Context c, String email) {
        String e = email.trim().toLowerCase(Locale.US);
        List<String> l = list(c);
        if (!l.contains(e)) l.add(e);
        save(c, l, e);
    }

    static void switchTo(Context c, String email) {
        save(c, list(c), email);
    }

    static void signOut(Context c) {
        save(c, list(c), "");
    }

    private static void save(Context c, List<String> l, String active) {
        StringBuilder sb = new StringBuilder();
        for (String e : l) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(e);
        }
        reg(c).edit().putString("list", sb.toString()).putString("active", active).apply();
    }
}
