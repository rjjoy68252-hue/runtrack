package com.runtrack.app;

import android.app.AlertDialog;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Profile, account, goals and settings. */
final class SettingsScreen extends Screen {

    SettingsScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        LinearLayout col = UI.page(a);
        col.addView(UI.tv(a, L.s("PROFILE", "প্রোফাইল"), 20, UI.TEXT, true), UI.lp(a, UI.WRAP, UI.WRAP, 0, 4));

        // ---------------- profile card ----------------
        LinearLayout profile = UI.card(a);
        profile.setGravity(Gravity.CENTER_HORIZONTAL);

        AvatarView avatar = new AvatarView(a, Photo.load(a));
        avatar.setOnClickListener(x -> showPhotoMenu());
        profile.addView(avatar, new LinearLayout.LayoutParams(UI.dp(a, 96), UI.dp(a, 96)));
        profile.addView(UI.tv(a, L.s("Tap photo to change", "ছবি বদলাতে ট্যাপ করুন"), 10, UI.MUTED, false),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 4));

        String nm = Prefs.name();
        TextView nameView = UI.tv(a, nm.isEmpty() ? L.s("Set your name", "নাম দিন") : nm, 22, UI.TEXT, true);
        nameView.setOnClickListener(x -> a.promptText(L.s("Your name", "আপনার নাম"), Prefs.name(), s -> {
            Prefs.setName(s.trim());
            a.refresh();
        }));
        profile.addView(nameView, UI.lp(a, UI.WRAP, UI.WRAP, 0, 10));

        String email = Accounts.active(a);
        profile.addView(UI.tv(a, email.isEmpty() ? L.s("Guest", "অতিথি") : email, 12,
                email.isEmpty() ? UI.MUTED : UI.ACCENT, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 2));

        LinearLayout stats = new LinearLayout(a);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(profileStat(L.s("Age", "বয়স"),
                Prefs.age() > 0 ? String.valueOf(Prefs.age()) : "--", () -> a.promptNumber(
                        L.s("Your age", "আপনার বয়স"), "20", false, v -> {
                            if (v >= 5 && v <= 110) {
                                Prefs.setAge((int) Math.round(v));
                                a.refresh();
                            }
                        })), new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        stats.addView(profileStat(L.s("Weight", "ওজন"), Prefs.weightKg() + " kg", () -> a.promptNumber(
                L.s("Weight in kg", "ওজন (কেজি)"), "65", true, v -> {
                    if (v >= 20 && v <= 300) {
                        Prefs.setWeightKg((int) Math.round(v));
                        Prefs.dayPut("weight", Fmt.dayKey(System.currentTimeMillis()), (float) v);
                        a.refresh();
                    }
                })), new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        stats.addView(profileStat(L.s("Height", "উচ্চতা"), Prefs.heightCm() + " cm", () -> a.promptNumber(
                L.s("Height in cm", "উচ্চতা (সেমি)"), "170", false, v -> {
                    if (v >= 100 && v <= 230) {
                        Prefs.setHeightCm((int) Math.round(v));
                        a.refresh();
                    }
                })), new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        profile.addView(stats, UI.lp(a, UI.MATCH, UI.WRAP, 0, 16));
        col.addView(profile, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- account ----------------
        LinearLayout acc = UI.card(a);
        acc.addView(header(L.s("ACCOUNT", "অ্যাকাউন্ট")));
        if (email.isEmpty()) {
            acc.addView(UI.tv(a, L.s("Sign in with your Gmail to keep your own profile, photo and health data.",
                    "নিজের প্রোফাইল, ছবি ও হেলথ ডেটা আলাদা রাখতে Gmail দিয়ে সাইন ইন করুন।"),
                    13, UI.TEXT, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 8));
        }
        LinearLayout accRow = new LinearLayout(a);
        accRow.setOrientation(LinearLayout.HORIZONTAL);
        Button signIn = UI.button(a, email.isEmpty()
                ? L.s("Sign in with Gmail", "Gmail দিয়ে সাইন ইন")
                : L.s("Add / switch account", "অ্যাকাউন্ট বদলান"), true);
        signIn.setOnClickListener(x -> {
            if (email.isEmpty() && Accounts.list(a).isEmpty()) {
                a.promptSignIn();
            } else {
                a.showAccountSwitcher();
            }
        });
        accRow.addView(signIn, new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        if (!email.isEmpty()) {
            Button out = UI.button(a, L.s("Sign out", "সাইন আউট"), false);
            out.setOnClickListener(x -> a.signOut());
            LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
            op.leftMargin = UI.dp(a, 10);
            accRow.addView(out, op);
        }
        acc.addView(accRow, UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));
        acc.addView(UI.tv(a, L.s("Accounts are saved on this phone only. They are not verified by Google and nothing is uploaded.",
                "অ্যাকাউন্ট শুধু এই ফোনে সেভ থাকে। Google যাচাই করে না, কিছু আপলোডও হয় না।"),
                11, UI.MUTED, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 10));
        col.addView(acc, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- goal setting ----------------
        LinearLayout goals = UI.card(a);
        goals.addView(header(L.s("GOAL SETTING", "লক্ষ্য ঠিক করুন")));
        LinearLayout tiles = new LinearLayout(a);
        tiles.setOrientation(LinearLayout.HORIZONTAL);
        tiles.addView(goalTile("⚖️", Prefs.weightKg() + " kg", L.s("Set weight", "ওজন"), () -> a.promptNumber(
                L.s("Weight in kg", "ওজন (কেজি)"), "65", true, v -> {
                    if (v >= 20 && v <= 300) {
                        Prefs.setWeightKg((int) Math.round(v));
                        Prefs.dayPut("weight", Fmt.dayKey(System.currentTimeMillis()), (float) v);
                        a.refresh();
                    }
                })), new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        LinearLayout.LayoutParams g2 = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        g2.leftMargin = UI.dp(a, 8);
        tiles.addView(goalTile("👟", Fmt.num(Prefs.stepGoal()), L.s("Steps", "স্টেপ"), () -> a.promptNumber(
                L.s("Daily step goal", "দৈনিক স্টেপ লক্ষ্য"), "8000", false, v -> {
                    if (v >= 1000 && v <= 60000) {
                        Prefs.setStepGoal((int) Math.round(v));
                        a.refresh();
                    }
                })), g2);
        LinearLayout.LayoutParams g3 = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        g3.leftMargin = UI.dp(a, 8);
        tiles.addView(goalTile("💧", String.format(Locale.US, "%.1f L", Prefs.waterGoal() / 1000.0),
                L.s("Water", "পানি"), () -> a.promptNumber(
                        L.s("Daily water goal (ml)", "দৈনিক পানির লক্ষ্য (ml)"), "2500", false, v -> {
                            if (v >= 500 && v <= 8000) {
                                Prefs.setWaterGoal((int) Math.round(v));
                                a.refresh();
                            }
                        })), g3);
        goals.addView(tiles, UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));
        col.addView(goals, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- settings ----------------
        LinearLayout set = UI.card(a);
        set.addView(header(L.s("SETTINGS", "সেটিংস")));

        set.addView(UI.tv(a, "🎨  " + L.s("Color accent", "মূল রং") + "  •  " + UI.accentName(), 15, UI.TEXT, false),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 12));
        set.addView(swatchRow(true), UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));

        if (!Prefs.lightMode()) {
            set.addView(UI.tv(a, "🖼  " + L.s("Background", "ব্যাকগ্রাউন্ড") + "  •  " + UI.bgName(), 15, UI.TEXT, false),
                    UI.lp(a, UI.WRAP, UI.WRAP, 0, 16));
            set.addView(swatchRow(false), UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));
        }
        set.addView(UI.divider(a), UI.lp(a, UI.MATCH, UI.dp(a, 1), 0, 12));

        Switch dark = new Switch(a);
        dark.setChecked(!Prefs.lightMode());
        dark.setOnCheckedChangeListener((b, on) -> {
            Prefs.setLightMode(!on);
            a.applyThemeAndRebuild();
        });
        set.addView(UI.settingRow(a, "🌙  " + L.s("Dark mode", "ডার্ক মোড"), dark));
        set.addView(UI.divider(a));

        Switch remind = new Switch(a);
        remind.setChecked(Prefs.waterRemind());
        remind.setOnCheckedChangeListener((b, on) -> {
            Prefs.setWaterRemind(on);
            if (on) {
                WaterReceiver.schedule(a);
                a.requestNotifications();
            } else {
                WaterReceiver.cancel(a);
            }
        });
        set.addView(UI.settingRow(a, "🔔  " + L.s("Notifications (water)", "নোটিফিকেশন (পানি)"), remind));
        set.addView(UI.divider(a));

        Button langBtn = UI.button(a, Prefs.bengali() ? "বাংলা" : "English", false);
        langBtn.setOnClickListener(x -> {
            Prefs.setBengali(!Prefs.bengali());
            a.rebuildAll();
        });
        set.addView(UI.settingRow(a, "🌐  " + L.s("Language", "ভাষা"), langBtn));
        set.addView(UI.divider(a));

        Button unitBtn = UI.button(a, Prefs.miles() ? "Miles (mi)" : "Kilometers (km)", false);
        unitBtn.setOnClickListener(x -> {
            Prefs.setMiles(!Prefs.miles());
            a.refresh();
        });
        set.addView(UI.settingRow(a, "📏  " + L.s("Distance unit", "দূরত্বের একক"), unitBtn));
        set.addView(UI.divider(a));

        Switch keep = new Switch(a);
        keep.setChecked(Prefs.keepScreenOn());
        keep.setOnCheckedChangeListener((b, on) -> Prefs.setKeepScreenOn(on));
        set.addView(UI.settingRow(a, "📱  " + L.s("Screen on while working out", "ওয়ার্কআউটে স্ক্রিন চালু"), keep));
        col.addView(set, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- more goals ----------------
        LinearLayout more = UI.card(a);
        more.addView(header(L.s("MORE GOALS", "আরও লক্ষ্য")));
        more.addView(UI.settingRow(a, L.s("Calories burn", "ক্যালোরি বার্ন"),
                UI.stepper(a, Prefs.calGoal(), 100, 3000, 50, "kcal", Prefs::setCalGoal)));
        more.addView(UI.divider(a));
        more.addView(UI.settingRow(a, L.s("Sleep", "ঘুম"),
                UI.stepper(a, Prefs.sleepGoalHours(), 4, 12, 1, L.s("h", "ঘ"), Prefs::setSleepGoalHours)));
        more.addView(UI.divider(a));
        more.addView(UI.settingRow(a, L.s("Weekly workout", "সাপ্তাহিক ওয়ার্কআউট"),
                UI.stepper(a, Prefs.weeklyGoal(), 1, 500, 1, Fmt.unit(), Prefs::setWeeklyGoal)));
        col.addView(more, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- about ----------------
        LinearLayout about = UI.hero(a);
        about.addView(header(L.s("ABOUT", "পরিচিতি")));
        about.addView(UI.tv(a, "RunTrack  v" + a.versionName(), 20, UI.ACCENT, true),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 8));
        about.addView(UI.tv(a, L.s("Developed by", "তৈরি করেছেন"), 13, UI.MUTED, false),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 14));
        about.addView(UI.tv(a, UI.DEV_NAME, 20, UI.TEXT, true), UI.lp(a, UI.WRAP, UI.WRAP, 0, 2));
        Button fb = UI.button(a, L.s("Open Facebook profile", "Facebook প্রোফাইল দেখুন"), true);
        fb.setOnClickListener(x -> a.openFacebook());
        about.addView(fb, UI.lp(a, UI.MATCH, UI.WRAP, 0, 14));
        about.addView(UI.tv(a, L.s("Steps, workouts, water, sleep and more in one place.",
                "স্টেপ, ওয়ার্কআউট, পানি, ঘুম আর আরও অনেক কিছু এক জায়গায়।"), 13, UI.MUTED, false),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 12));
        col.addView(about, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- data ----------------
        Button clear = UI.button(a, L.s("Clear workout history", "ওয়ার্কআউটের ইতিহাস মুছুন"), false);
        clear.setTextColor(UI.DANGER);
        clear.setOnClickListener(x -> new AlertDialog.Builder(a)
                .setTitle(L.s("Clear all workouts?", "সব ওয়ার্কআউট মুছবেন?"))
                .setMessage(L.s("This cannot be undone.", "এটি আর ফেরত আনা যাবে না।"))
                .setPositiveButton(L.s("Clear", "মুছুন"), (d, w) -> {
                    Prefs.clearRuns();
                    Toast.makeText(a, L.s("History cleared", "ইতিহাস মুছে ফেলা হয়েছে"),
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(L.s("Cancel", "বাতিল"), null)
                .show());
        col.addView(clear, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        return UI.scroll(a, col);
    }

    private TextView header(String s) {
        return UI.tv(a, s, 12, UI.MUTED, true);
    }

    private void showPhotoMenu() {
        CharSequence[] items = {
                L.s("Choose photo", "ছবি বাছুন"),
                L.s("Remove photo", "ছবি সরান")
        };
        new AlertDialog.Builder(a)
                .setTitle(L.s("Profile photo", "প্রোফাইল ছবি"))
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        a.pickPhoto();
                    } else {
                        Photo.remove(a);
                        a.refresh();
                    }
                })
                .show();
    }

    private View profileStat(String label, String value, final Runnable onTap) {
        LinearLayout b = new LinearLayout(a);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER_HORIZONTAL);
        b.addView(UI.tv(a, label, 11, UI.MUTED, false));
        b.addView(UI.tv(a, value, 17, UI.TEXT, true), UI.lp(a, UI.WRAP, UI.WRAP, 0, 2));
        b.setPadding(0, UI.dp(a, 6), 0, UI.dp(a, 6));
        b.setOnClickListener(x -> onTap.run());
        return b;
    }

    private View goalTile(String emoji, String value, String label, final Runnable onTap) {
        LinearLayout t = new LinearLayout(a);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(UI.dp(a, 6), UI.dp(a, 14), UI.dp(a, 6), UI.dp(a, 14));
        t.setBackground(UI.round(UI.LINE, 16, a));
        t.addView(UI.tv(a, emoji, 22, UI.TEXT, false));
        t.addView(UI.tv(a, value, 16, UI.TEXT, true), UI.lp(a, UI.WRAP, UI.WRAP, 0, 4));
        t.addView(UI.tv(a, label, 11, UI.MUTED, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 2));
        t.setOnClickListener(x -> onTap.run());
        return t;
    }

    /** Row of round color swatches. accent = true for accent colors, false for backgrounds. */
    private View swatchRow(final boolean accent) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int n = accent ? UI.ACCENT_COLORS.length : UI.BG_SETS.length;
        int selected = accent ? Prefs.accentIndex() : Prefs.bgIndex();
        for (int i = 0; i < n; i++) {
            final int idx = i;
            View s = new View(a);
            int fill = accent ? UI.ACCENT_COLORS[i] : UI.BG_SETS[i][1];
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(fill);
            g.setStroke(UI.dp(a, i == selected ? 3 : 1), i == selected ? UI.TEXT : UI.STROKE);
            s.setBackground(g);
            s.setOnClickListener(x -> {
                if (accent) {
                    Prefs.setAccentIndex(idx);
                } else {
                    Prefs.setBgIndex(idx);
                }
                a.applyThemeAndRebuild();
            });
            int size = UI.dp(a, accent ? 27 : 38);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(size, size);
            if (i > 0) p.leftMargin = UI.dp(a, accent ? 6 : 12);
            row.addView(s, p);
        }
        return row;
    }
}
