package com.runtrack.app;

import android.app.AlertDialog;
import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Small shared UI pieces used by more than one screen. */
final class Widgets {
    private Widgets() {}

    static Calendar todayStart() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    /** Start of this week (Monday 00:00) in millis. */
    static long weekStartMillis() {
        Calendar c = todayStart();
        int dow = c.get(Calendar.DAY_OF_WEEK); // Sunday = 1
        int sinceMonday = (dow + 5) % 7;
        c.add(Calendar.DAY_OF_YEAR, -sinceMonday);
        return c.getTimeInMillis();
    }

    static double metersSince(List<Run> runs, long from) {
        double total = 0;
        for (Run r : runs) {
            if (r.id >= from) total += r.meters;
        }
        return total;
    }

    static View weeklyGoalCard(Context c, List<Run> runs) {
        LinearLayout card = UI.card(c);
        double done = metersSince(runs, weekStartMillis());
        int goal = Prefs.weeklyGoal();
        double goalMeters = goal * Fmt.unitMeters();

        card.addView(UI.tv(c, L.s("WEEKLY WORKOUT GOAL", "সাপ্তাহিক ওয়ার্কআউট লক্ষ্য"),
                12, UI.MUTED, true));
        String val = String.format(Locale.US, "%.2f / %d %s", done / Fmt.unitMeters(), goal, Fmt.unit());
        card.addView(UI.tv(c, val, 18, UI.TEXT, true), UI.lp(c, UI.WRAP, UI.WRAP, 0, 4));
        card.addView(UI.progressBar(c, (float) (done / goalMeters), UI.ACCENT),
                UI.lp(c, UI.MATCH, UI.dp(c, 10), 0, 10));
        return card;
    }

    static View statCard(Context c, String label, String value) {
        LinearLayout card = UI.card(c);
        card.addView(UI.tv(c, label, 11, UI.MUTED, true));
        card.addView(UI.tv(c, value, 20, UI.TEXT, true), UI.lp(c, UI.WRAP, UI.WRAP, 0, 4));
        return card;
    }

    /** Two cards side by side. */
    static LinearLayout pair(Context c, View left, View right) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(left, new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        rp.leftMargin = UI.dp(c, 10);
        row.addView(right, rp);
        return row;
    }

    static View chartCard(Context c, String title, float[] data, String[] labels, int color, float goal) {
        LinearLayout card = UI.card(c);
        card.addView(UI.tv(c, title, 12, UI.MUTED, true));
        BarChartView chart = new BarChartView(c);
        chart.set(data, labels, color, goal);
        card.addView(chart, UI.lp(c, UI.MATCH, UI.dp(c, 150), 0, 10));
        return card;
    }

    static String summary(Run r) {
        return Fmt.modeIcon(r.type) + " " + Fmt.modeName(r.type) + "\n"
                + L.s("Distance: ", "দূরত্ব: ") + Fmt.dist(r.meters) + "\n"
                + L.s("Time: ", "সময়: ") + Fmt.clock(r.seconds) + "\n"
                + (r.type == 2
                ? L.s("Speed: ", "গতি: ") + Fmt.speed(r.meters, r.seconds)
                : L.s("Pace: ", "পেস: ") + Fmt.paceWithUnit(r.meters, r.seconds)) + "\n"
                + L.s("Calories: ", "ক্যালোরি: ") + r.calories + " kcal";
    }

    /** Dialog with the route and details of one workout, with a delete button. */
    static void showRunDetail(final MainActivity a, final Run r) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(a, 16);
        box.setPadding(p, p, p, p);

        RouteView rv = new RouteView(a);
        rv.setPoints(r.points());
        box.addView(rv, new LinearLayout.LayoutParams(UI.MATCH, UI.dp(a, 200)));
        box.addView(UI.tv(a, summary(r), 15, UI.TEXT, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 12));

        new AlertDialog.Builder(a)
                .setTitle(Fmt.date(r.id))
                .setView(box)
                .setPositiveButton(L.s("Close", "বন্ধ"), null)
                .setNegativeButton(L.s("Delete", "মুছুন"), (d, w) -> {
                    Prefs.deleteRun(r.id);
                    a.refresh();
                })
                .show();
    }

    /** One line of a workout list: icon, name + date on the left, distance + time on the right. */
    static View runRow(final MainActivity a, final Run r) {
        LinearLayout row = UI.row(a);
        row.setPadding(0, UI.dp(a, 10), 0, UI.dp(a, 10));
        row.addView(UI.tv(a, Fmt.modeIcon(r.type), 24, UI.TEXT, false),
                new LinearLayout.LayoutParams(UI.dp(a, 40), UI.WRAP));

        LinearLayout mid = new LinearLayout(a);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.addView(UI.tv(a, Fmt.modeName(r.type), 15, UI.TEXT, true));
        mid.addView(UI.tv(a, Fmt.date(r.id), 11, UI.MUTED, false));
        row.addView(mid, new LinearLayout.LayoutParams(0, UI.WRAP, 1f));

        LinearLayout end = new LinearLayout(a);
        end.setOrientation(LinearLayout.VERTICAL);
        end.setGravity(android.view.Gravity.END);
        end.addView(UI.tv(a, Fmt.dist(r.meters), 15, UI.ACCENT, true));
        end.addView(UI.tv(a, Fmt.clock(r.seconds), 11, UI.MUTED, false));
        row.addView(end, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));

        row.setOnClickListener(x -> showRunDetail(a, r));
        return row;
    }
}
