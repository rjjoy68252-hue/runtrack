package com.runtrack.app;

import android.app.AlertDialog;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Home: calories ring, steps / heart rate / activity minutes, daily tasks and highlights. */
final class HomeScreen extends Screen {
    private RingView ring;
    private TextView stepsVal, hrVal, minVal;
    private TextView waterVal, sleepVal;
    private TextView goalNote;
    private LinearLayout tasksCard;
    private List<Run> runs;

    HomeScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        runs = Prefs.runs();
        LinearLayout col = UI.page(a);

        // ---------------- greeting ----------------
        LinearLayout hi = UI.card(a);
        LinearLayout hiRow = UI.row(a);
        LinearLayout hiText = new LinearLayout(a);
        hiText.setOrientation(LinearLayout.VERTICAL);
        String nm = Prefs.name();
        hiText.addView(UI.tv(a, L.s("Hi, ", "হ্যালো, ") + (nm.isEmpty() ? "RunTrack" : nm), 20, UI.TEXT, true));
        String when = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(new Date());
        hiText.addView(UI.tv(a, L.s("Last updated ", "সর্বশেষ আপডেট ") + when, 11, UI.MUTED, false));
        String email = Accounts.active(a);
        if (!email.isEmpty()) {
            hiText.addView(UI.tv(a, email, 11, UI.ACCENT, false));
        }
        hiRow.addView(hiText, new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        AvatarView av = new AvatarView(a, Photo.load(a));
        av.setOnClickListener(x -> a.go(4));
        hiRow.addView(av, new LinearLayout.LayoutParams(UI.dp(a, 52), UI.dp(a, 52)));
        hi.addView(hiRow);
        col.addView(hi, UI.lp(a, UI.MATCH, UI.WRAP, 0, 4));

        // permission / sensor note
        if (!a.hasActivityPermission()) {
            LinearLayout note = UI.card(a);
            note.addView(UI.tv(a,
                    L.s("Allow \"Physical activity\" to count your steps.",
                            "স্টেপ গোনার জন্য \"Physical activity\" অনুমতি দিন।"),
                    14, UI.TEXT, false));
            Button b = UI.button(a, L.s("Allow", "অনুমতি দিন"), true);
            b.setOnClickListener(x -> a.requestActivity());
            note.addView(b, UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));
            col.addView(note, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        } else if (!a.stepSensorPresent()) {
            LinearLayout note = UI.card(a);
            note.addView(UI.tv(a,
                    L.s("This phone has no step sensor. Workouts still work with GPS.",
                            "এই ফোনে স্টেপ সেন্সর নেই। GPS দিয়ে ওয়ার্কআউট ঠিকই চলবে।"),
                    14, UI.TEXT, false));
            col.addView(note, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        }

        // ---------------- calories ring ----------------
        LinearLayout ringCard = UI.hero(a);
        ringCard.setGravity(Gravity.CENTER_HORIZONTAL);
        ring = new RingView(a);
        ringCard.addView(ring, new LinearLayout.LayoutParams(UI.dp(a, 190), UI.dp(a, 190)));
        goalNote = UI.tv(a, "", 12, UI.MUTED, false);
        ringCard.addView(goalNote, UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));
        col.addView(ringCard, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- three tiles ----------------
        LinearLayout tiles = new LinearLayout(a);
        tiles.setOrientation(LinearLayout.HORIZONTAL);
        stepsVal = tile(tiles, "👟", L.s("Steps", "স্টেপ"), true, 1);
        hrVal = tile(tiles, "❤️", L.s("Heart Rate", "হার্ট রেট"), false, 2);
        minVal = tile(tiles, "🔥", L.s("Activity Minutes", "অ্যাক্টিভ মিনিট"), false, 3);
        col.addView(tiles, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- daily tasks ----------------
        tasksCard = UI.card(a);
        col.addView(tasksCard, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        fillTasks();

        // ---------------- water / sleep ----------------
        LinearLayout minis = new LinearLayout(a);
        minis.setOrientation(LinearLayout.HORIZONTAL);
        waterVal = mini(minis, "💧", L.s("WATER", "পানি"), UI.BLUE, true);
        sleepVal = mini(minis, "😴", L.s("SLEEP", "ঘুম"), UI.PURPLE, false);
        col.addView(minis, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- streak ----------------
        int streak = Stats.streak(runs);
        LinearLayout sc = UI.card(a, UI.blend(UI.GOLD, UI.BG, 0.85f), UI.blend(UI.GOLD, UI.BG, 0.94f),
                UI.withAlpha(UI.GOLD, 0x66));
        LinearLayout sr = UI.row(a);
        sr.addView(UI.tv(a, "🔥", 30, UI.TEXT, false), new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        LinearLayout st = new LinearLayout(a);
        st.setOrientation(LinearLayout.VERTICAL);
        st.addView(UI.tv(a, L.s(streak + " day streak", streak + " দিনের স্ট্রিক"), 18, UI.GOLD, true));
        st.addView(UI.tv(a, L.s("Best: ", "সেরা: ") + Prefs.bestStreak() + L.s(" days", " দিন")
                + "  •  " + L.s("Reach your step goal or work out daily",
                "রোজ স্টেপ লক্ষ্য বা ওয়ার্কআউট করুন"), 11, UI.MUTED, false));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        sp.leftMargin = UI.dp(a, 12);
        sr.addView(st, sp);
        sc.addView(sr);
        col.addView(sc, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- steps chart ----------------
        col.addView(Widgets.chartCard(a, L.s("STEPS  •  LAST 7 DAYS", "স্টেপ  •  গত ৭ দিন"),
                Stats.series("steps", 7), Stats.labels(7), UI.ACCENT, Prefs.stepGoal()),
                UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- last workout ----------------
        if (!runs.isEmpty()) {
            LinearLayout card = UI.card(a);
            card.addView(UI.tv(a, L.s("LAST WORKOUT", "শেষ ওয়ার্কআউট"), 12, UI.MUTED, true));
            card.addView(Widgets.runRow(a, runs.get(0)));
            col.addView(card, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        }

        View v = UI.scroll(a, col);
        update();
        return v;
    }

    /** A small square card: emoji, big value, label. */
    private TextView tile(LinearLayout row, String emoji, String label, boolean first, final int target) {
        LinearLayout card = UI.card(a);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = UI.dp(a, 10);
        card.setPadding(p, UI.dp(a, 14), p, UI.dp(a, 14));
        card.addView(UI.tv(a, emoji, 26, UI.TEXT, false));
        TextView val = UI.tv(a, "--", 20, UI.TEXT, true);
        val.setGravity(Gravity.CENTER);
        card.addView(val, UI.lp(a, UI.WRAP, UI.WRAP, 0, 4));
        TextView l = UI.tv(a, label, 11, UI.MUTED, false);
        l.setGravity(Gravity.CENTER);
        card.addView(l, UI.lp(a, UI.WRAP, UI.WRAP, 0, 2));
        card.setOnClickListener(x -> a.go(target == 1 ? 3 : (target == 2 ? 2 : 1)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        if (!first) lp.leftMargin = UI.dp(a, 8);
        row.addView(card, lp);
        return val;
    }

    private TextView mini(LinearLayout row, String emoji, String label, int color, boolean first) {
        LinearLayout card = UI.card(a);
        int p = UI.dp(a, 12);
        card.setPadding(p, p, p, p);
        card.addView(UI.tv(a, emoji + " " + label, 11, UI.MUTED, true));
        TextView val = UI.tv(a, "--", 17, color, true);
        card.addView(val, UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));
        card.setOnClickListener(x -> a.go(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        if (!first) lp.leftMargin = UI.dp(a, 8);
        row.addView(card, lp);
        return val;
    }

    // ------------------------------------------------------------------
    // daily tasks
    // ------------------------------------------------------------------

    private void fillTasks() {
        tasksCard.removeAllViews();

        LinearLayout head = UI.row(a);
        head.addView(UI.tv(a, L.s("DAILY TASK", "দৈনিক কাজ"), 12, UI.MUTED, true),
                new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        TextView more = UI.tv(a, "•••", 18, UI.TEXT, true);
        more.setPadding(UI.dp(a, 12), 0, 0, 0);
        more.setOnClickListener(x -> showTaskMenu());
        head.addView(more, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        tasksCard.addView(head);

        List<Tasks.Task> list = Tasks.list();
        if (list.isEmpty()) {
            tasksCard.addView(UI.tv(a, L.s("No tasks. Tap ••• to add one.", "কোনো কাজ নেই। ••• চেপে যোগ করুন।"),
                    14, UI.MUTED, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 10));
        }
        for (final Tasks.Task t : list) {
            final boolean done = Tasks.done(t, runs);
            LinearLayout row = UI.row(a);
            row.setPadding(0, UI.dp(a, 10), 0, UI.dp(a, 10));

            TextView box = UI.tv(a, done ? "✓" : "", 14, UI.ON_ACCENT, true);
            box.setGravity(Gravity.CENTER);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(UI.dp(a, 6));
            if (done) {
                g.setColor(UI.ACCENT);
            } else {
                g.setColor(0);
                g.setStroke(UI.dp(a, 2), UI.MUTED);
            }
            box.setBackground(g);
            row.addView(box, new LinearLayout.LayoutParams(UI.dp(a, 24), UI.dp(a, 24)));

            TextView title = UI.tv(a, Tasks.title(t), 15, done ? UI.MUTED : UI.TEXT, false);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
            tp.leftMargin = UI.dp(a, 12);
            row.addView(title, tp);

            row.setOnClickListener(x -> {
                if (t.auto()) {
                    Toast.makeText(a, L.s("Ticks automatically", "নিজে থেকে টিক হয়"),
                            Toast.LENGTH_SHORT).show();
                } else {
                    Tasks.toggle(t);
                    fillTasks();
                }
            });
            tasksCard.addView(row);
            tasksCard.addView(UI.divider(a));
        }
    }

    private void showTaskMenu() {
        CharSequence[] items = {
                L.s("Add task", "কাজ যোগ করুন"),
                L.s("Remove a task", "কাজ মুছুন"),
                L.s("Reset to default", "ডিফল্ট করুন")
        };
        new AlertDialog.Builder(a)
                .setTitle(L.s("Daily tasks", "দৈনিক কাজ"))
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        a.promptText(L.s("New task", "নতুন কাজ"), "", s -> {
                            String t = s.trim();
                            if (!t.isEmpty()) {
                                Tasks.add(t);
                                fillTasks();
                            }
                        });
                    } else if (which == 1) {
                        showRemoveDialog();
                    } else {
                        Tasks.reset();
                        fillTasks();
                    }
                })
                .show();
    }

    private void showRemoveDialog() {
        final List<Tasks.Task> list = Tasks.list();
        if (list.isEmpty()) return;
        CharSequence[] names = new CharSequence[list.size()];
        for (int i = 0; i < names.length; i++) names[i] = Tasks.title(list.get(i));
        new AlertDialog.Builder(a)
                .setTitle(L.s("Remove which task?", "কোন কাজটি মুছবেন?"))
                .setItems(names, (d, which) -> {
                    Tasks.remove(list.get(which).id);
                    fillTasks();
                })
                .show();
    }

    // ------------------------------------------------------------------
    // live values
    // ------------------------------------------------------------------

    private void update() {
        if (ring == null) return;
        double[] t = Stats.today(runs);
        int kcal = (int) Math.round(t[1]);
        int goal = Math.max(1, Prefs.calGoal());
        ring.set(kcal / (float) goal, UI.ACCENT, String.valueOf(kcal), L.s("BURN kcal", "কিলোক্যালোরি"));
        goalNote.setText(L.s("Goal ", "লক্ষ্য ") + goal + " kcal  •  " + Fmt.dist(t[0]));

        long steps = Prefs.stepsToday();
        stepsVal.setText(Fmt.num(steps));
        float[] hr = Stats.recent("hr", 60);
        hrVal.setText(hr[0] < 0 ? "--" : String.valueOf(Math.round(hr[0])));
        minVal.setText(String.valueOf(Math.round(t[2])));

        String today = Fmt.dayKey(System.currentTimeMillis());
        waterVal.setText(Math.round(Prefs.dayGet("water", today, 0f)) + " ml");
        float sleep = Prefs.dayGet("sleep", today, -1f);
        sleepVal.setText(sleep < 0 ? "--" : Fmt.hm(Math.round(sleep)));
    }

    @Override
    void tick() {
        update();
    }
}
