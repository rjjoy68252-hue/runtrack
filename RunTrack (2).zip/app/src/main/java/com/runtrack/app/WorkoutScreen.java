package com.runtrack.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** Workout: pick Run / Walk / Cycle, start, live stats, and the recent workouts list. */
final class WorkoutScreen extends Screen {
    private TextView statusText, timeText, distText, paceText, calText, paceLabel;
    private Button startBtn, pauseBtn, stopBtn;
    private LinearLayout idleBox, activeBox;
    private RouteView routeView;
    private final LinearLayout[] tiles = new LinearLayout[3];
    private final TextView[] tileLabels = new TextView[3];

    WorkoutScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        LinearLayout col = UI.page(a);

        col.addView(UI.tv(a, L.s("START WORKOUT", "ওয়ার্কআউট শুরু করুন"), 20, UI.TEXT, true),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 4));
        col.addView(UI.tv(a, L.s("SELECT YOUR ACTIVITY", "আপনার অ্যাক্টিভিটি বাছুন"), 12, UI.MUTED, true),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 16));

        // ---------------- activity tiles ----------------
        LinearLayout tileRow = new LinearLayout(a);
        tileRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            LinearLayout t = new LinearLayout(a);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, UI.dp(a, 16), 0, UI.dp(a, 14));
            t.addView(UI.tv(a, Fmt.modeIcon(i), 28, UI.TEXT, false), new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
            TextView lab = UI.tv(a, Fmt.modeName(i).toUpperCase(), 12, UI.TEXT, true);
            t.addView(lab, UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));
            t.setOnClickListener(x -> {
                if (RunState.active) return;
                RunState.mode = idx;
                styleTiles();
                updateUi();
            });
            tiles[i] = t;
            tileLabels[i] = lab;
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
            if (i > 0) p.leftMargin = UI.dp(a, 10);
            tileRow.addView(t, p);
        }
        col.addView(tileRow, UI.lp(a, UI.MATCH, UI.WRAP, 0, 8));
        styleTiles();

        // ---------------- start / live card ----------------
        LinearLayout card = UI.card(a);
        card.setGravity(Gravity.CENTER_HORIZONTAL);

        idleBox = new LinearLayout(a);
        idleBox.setOrientation(LinearLayout.VERTICAL);
        idleBox.setGravity(Gravity.CENTER_HORIZONTAL);
        idleBox.addView(UI.tv(a, "📍", 44, UI.TEXT, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 8));
        startBtn = UI.button(a, "", true);
        startBtn.setTextSize(17);
        startBtn.setBackground(UI.round(UI.ACCENT, 28, a));
        startBtn.setPadding(UI.dp(a, 40), UI.dp(a, 14), UI.dp(a, 40), UI.dp(a, 14));
        startBtn.setOnClickListener(x -> startRunFlow());
        idleBox.addView(startBtn, UI.lp(a, UI.WRAP, UI.WRAP, 0, 14));
        TextView hint = UI.tv(a, L.s("GPS required  •  outdoors", "GPS লাগবে  •  খোলা জায়গায়"), 11, UI.MUTED, false);
        idleBox.addView(hint, UI.lp(a, UI.WRAP, UI.WRAP, 0, 12));
        card.addView(idleBox, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));

        activeBox = new LinearLayout(a);
        activeBox.setOrientation(LinearLayout.VERTICAL);
        activeBox.setGravity(Gravity.CENTER_HORIZONTAL);
        statusText = UI.tv(a, "", 13, UI.ACCENT, true);
        activeBox.addView(statusText, UI.lp(a, UI.WRAP, UI.WRAP, 0, 0));
        timeText = UI.tv(a, "00:00:00", 48, UI.TEXT, true);
        timeText.setGravity(Gravity.CENTER);
        activeBox.addView(timeText, UI.lp(a, UI.WRAP, UI.WRAP, 0, 8));
        activeBox.addView(UI.tv(a, L.s("TIME", "সময়"), 11, UI.MUTED, true), UI.lp(a, UI.WRAP, UI.WRAP, 0, 0));

        LinearLayout stats = new LinearLayout(a);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        distText = UI.tv(a, "0.00 km", 20, UI.ACCENT, true);
        paceText = UI.tv(a, "--:-- /km", 20, UI.TEXT, true);
        calText = UI.tv(a, "0 kcal", 20, UI.ORANGE, true);
        paceLabel = UI.tv(a, L.s("PACE", "পেস"), 11, UI.MUTED, true);
        stats.addView(statBlock(distText, UI.tv(a, L.s("DISTANCE", "দূরত্ব"), 11, UI.MUTED, true)),
                new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        stats.addView(statBlock(paceText, paceLabel), new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        stats.addView(statBlock(calText, UI.tv(a, L.s("CALORIES", "ক্যালোরি"), 11, UI.MUTED, true)),
                new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        activeBox.addView(stats, UI.lp(a, UI.MATCH, UI.WRAP, 0, 20));

        routeView = new RouteView(a);
        routeView.setVisibility(View.GONE);
        activeBox.addView(routeView, UI.lp(a, UI.MATCH, UI.dp(a, 170), 0, 16));

        LinearLayout btnRow = new LinearLayout(a);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        pauseBtn = UI.button(a, "", false);
        stopBtn = UI.button(a, L.s("STOP", "শেষ করুন"), false);
        stopBtn.setTextColor(0xFFFFFFFF);
        stopBtn.setBackground(UI.round(UI.DANGER, 14, a));
        btnRow.addView(pauseBtn, new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        sp.leftMargin = UI.dp(a, 10);
        btnRow.addView(stopBtn, sp);
        activeBox.addView(btnRow, UI.lp(a, UI.MATCH, UI.WRAP, 0, 16));
        card.addView(activeBox, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));

        pauseBtn.setOnClickListener(x -> {
            if (RunState.paused) {
                RunState.resume();
            } else {
                RunState.pause();
            }
            updateUi();
        });
        stopBtn.setOnClickListener(x -> stopRun());
        col.addView(card, UI.lp(a, UI.MATCH, UI.WRAP, 0, 14));

        // ---------------- recent workouts ----------------
        col.addView(UI.tv(a, L.s("RECENT WORKOUTS", "সাম্প্রতিক ওয়ার্কআউট"), 12, UI.MUTED, true),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 20));
        List<Run> runs = Prefs.runs();
        LinearLayout list = UI.card(a);
        if (runs.isEmpty()) {
            list.addView(UI.tv(a, L.s("No workouts yet.", "এখনও কোনো ওয়ার্কআউট নেই।"), 14, UI.MUTED, false));
        }
        int n = Math.min(5, runs.size());
        for (int i = 0; i < n; i++) {
            if (i > 0) list.addView(UI.divider(a));
            list.addView(Widgets.runRow(a, runs.get(i)));
        }
        col.addView(list, UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));

        View v = UI.scroll(a, col);
        updateUi();
        return v;
    }

    private View statBlock(TextView value, TextView label) {
        LinearLayout b = new LinearLayout(a);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER_HORIZONTAL);
        value.setGravity(Gravity.CENTER);
        b.addView(value, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        b.addView(label, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        return b;
    }

    private void styleTiles() {
        for (int i = 0; i < 3; i++) {
            boolean sel = i == RunState.mode;
            tiles[i].setBackground(sel
                    ? UI.round(UI.ACCENT, 18, a)
                    : UI.gradient(a, UI.CARD_TOP, UI.CARD_BOTTOM, 18, UI.STROKE));
            tileLabels[i].setTextColor(sel ? UI.ON_ACCENT : UI.TEXT);
            tiles[i].setAlpha(RunState.active && !sel ? 0.4f : 1f);
        }
    }

    private void updateUi() {
        if (timeText == null) return;
        boolean act = RunState.active;
        boolean pz = RunState.paused;

        idleBox.setVisibility(act ? View.GONE : View.VISIBLE);
        activeBox.setVisibility(act ? View.VISIBLE : View.GONE);
        startBtn.setText(L.s("START", "শুরু করুন") + "  " + Fmt.modeName(RunState.mode).toUpperCase());
        startBtn.setTextColor(UI.ON_ACCENT);
        styleTiles();

        if (!act) {
            if (a.getWindow() != null) {
                a.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
            return;
        }

        statusText.setText(pz ? L.s("PAUSED", "বিরতি") : L.s("IN PROGRESS", "চলছে"));
        long sec = RunState.elapsedMs() / 1000;
        double m = RunState.meters;
        timeText.setText(Fmt.clock(sec));
        distText.setText(Fmt.dist(m));
        if (RunState.mode == 2) {
            paceLabel.setText(L.s("SPEED", "গতি"));
            paceText.setText(Fmt.speed(m, sec));
        } else {
            paceLabel.setText(L.s("PACE", "পেস"));
            paceText.setText(Fmt.paceWithUnit(m, sec));
        }
        calText.setText(Fmt.calories(m, RunState.mode) + " kcal");
        pauseBtn.setText(pz ? L.s("RESUME", "চালু করুন") : L.s("PAUSE", "বিরতি"));

        if (RunState.points.size() >= 2) {
            routeView.setPoints(RunState.points);
            routeView.setVisibility(View.VISIBLE);
        } else {
            routeView.setVisibility(View.GONE);
        }

        if (Prefs.keepScreenOn()) {
            a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            a.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    @Override
    void tick() {
        updateUi();
    }

    /** Also called by the activity after the location permission was granted. */
    void startRunFlow() {
        if (a.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            a.requestLocation();
            return;
        }
        LocationManager lm = (LocationManager) a.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null || !lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(a, L.s("Please turn on GPS", "অনুগ্রহ করে GPS চালু করুন"),
                    Toast.LENGTH_LONG).show();
            return;
        }
        RunState.begin();
        Intent i = new Intent(a, RunningService.class);
        i.setAction(RunningService.ACTION_START);
        a.startForegroundService(i);
        updateUi();
    }

    private void stopRun() {
        Run r = RunState.finishRun();
        Intent i = new Intent(a, RunningService.class);
        i.setAction(RunningService.ACTION_STOP);
        a.startService(i);
        if (r != null) {
            Prefs.addRun(r);
            new AlertDialog.Builder(a)
                    .setTitle(L.s("Workout saved", "ওয়ার্কআউট সেভ হয়েছে"))
                    .setMessage(Widgets.summary(r))
                    .setPositiveButton("OK", null)
                    .show();
        } else {
            Toast.makeText(a, L.s("Too short, not saved", "খুব ছোট, সেভ হয়নি"),
                    Toast.LENGTH_SHORT).show();
        }
        a.refresh();
    }
}
