package com.runtrack.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** Settings, daily health logs, step counting and workout history. */
final class Prefs {
    private static SharedPreferences sp;

    private Prefs() {}

    static void init(Context c) {
        if (sp == null) {
            sp = c.getApplicationContext()
                    .getSharedPreferences(Accounts.prefsName(c), Context.MODE_PRIVATE);
        }
    }

    /** Switches to the data of the currently active account. */
    static void reload(Context c) {
        sp = null;
        init(c);
    }

    // ------------------------------------------------------------------
    // settings
    // ------------------------------------------------------------------

    static boolean bengali() { return sp.getBoolean("bn", true); }
    static void setBengali(boolean v) { sp.edit().putBoolean("bn", v).apply(); }

    static boolean miles() { return sp.getBoolean("miles", false); }
    static void setMiles(boolean v) { sp.edit().putBoolean("miles", v).apply(); }

    static String name() { return sp.getString("name", ""); }
    static void setName(String v) { sp.edit().putString("name", v).apply(); }

    static int weightKg() { return sp.getInt("weight", 65); }
    static void setWeightKg(int v) { sp.edit().putInt("weight", v).apply(); }

    static int heightCm() { return sp.getInt("height", 170); }
    static void setHeightCm(int v) { sp.edit().putInt("height", v).apply(); }

    static int stepGoal() { return sp.getInt("step_goal", 8000); }
    static void setStepGoal(int v) { sp.edit().putInt("step_goal", v).apply(); }

    static int waterGoal() { return sp.getInt("water_goal", 2500); }
    static void setWaterGoal(int v) { sp.edit().putInt("water_goal", v).apply(); }

    static int sleepGoalHours() { return sp.getInt("sleep_goal", 8); }
    static void setSleepGoalHours(int v) { sp.edit().putInt("sleep_goal", v).apply(); }

    /** Weekly workout distance goal, in the unit currently selected (km or miles). */
    static int weeklyGoal() { return sp.getInt("goal", 20); }
    static void setWeeklyGoal(int v) { sp.edit().putInt("goal", v).apply(); }

    static boolean keepScreenOn() { return sp.getBoolean("keep_on", true); }
    static void setKeepScreenOn(boolean v) { sp.edit().putBoolean("keep_on", v).apply(); }

    static boolean waterRemind() { return sp.getBoolean("water_remind", false); }
    static void setWaterRemind(boolean v) { sp.edit().putBoolean("water_remind", v).apply(); }

    static int accentIndex() { return sp.getInt("accent", 0); }
    static void setAccentIndex(int v) { sp.edit().putInt("accent", v).apply(); }

    static int bgIndex() { return sp.getInt("bg", 0); }
    static void setBgIndex(int v) { sp.edit().putInt("bg", v).apply(); }

    static int age() { return sp.getInt("age", 0); }
    static void setAge(int v) { sp.edit().putInt("age", v).apply(); }

    static int calGoal() { return sp.getInt("cal_goal", 500); }
    static void setCalGoal(int v) { sp.edit().putInt("cal_goal", v).apply(); }

    static boolean lightMode() { return sp.getBoolean("light", false); }
    static void setLightMode(boolean v) { sp.edit().putBoolean("light", v).apply(); }

    static int themeVer() { return sp.getInt("theme_ver", 0); }
    static void setThemeVer(int v) { sp.edit().putInt("theme_ver", v).apply(); }

    // generic helpers (daily tasks)
    static String str(String key, String def) { return sp.getString(key, def); }
    static void putStr(String key, String v) { sp.edit().putString(key, v).apply(); }
    static boolean flag(String key) { return sp.getBoolean(key, false); }
    static void setFlag(String key, boolean v) { sp.edit().putBoolean(key, v).apply(); }

    static boolean askedActivity() { return sp.getBoolean("asked_activity", false); }
    static void setAskedActivity(boolean v) { sp.edit().putBoolean("asked_activity", v).apply(); }

    static int bestStreak() { return sp.getInt("best_streak", 0); }
    static void setBestStreak(int v) { sp.edit().putInt("best_streak", v).apply(); }

    static boolean badge(String id) { return sp.getBoolean("badge_" + id, false); }
    static void setBadge(String id) { sp.edit().putBoolean("badge_" + id, true).apply(); }

    static int lastWater() { return sp.getInt("water_last", 0); }
    static void setLastWater(int v) { sp.edit().putInt("water_last", v).apply(); }

    // ------------------------------------------------------------------
    // daily values: steps, water (ml), sleep (minutes), weight (kg), hr (bpm)
    // ------------------------------------------------------------------

    static float dayGet(String type, String key, float def) {
        return sp.getFloat("d_" + type + "_" + key, def);
    }

    static void dayPut(String type, String key, float v) {
        sp.edit().putFloat("d_" + type + "_" + key, v).apply();
    }

    static void dayRemove(String type, String key) {
        sp.edit().remove("d_" + type + "_" + key).apply();
    }

    // ------------------------------------------------------------------
    // step counter (phone sensor: total steps since boot)
    // ------------------------------------------------------------------

    static long stepsToday() {
        return Math.round(dayGet("steps", Fmt.dayKey(System.currentTimeMillis()), 0f));
    }

    static void onStepSensor(long total) {
        String today = Fmt.dayKey(System.currentTimeMillis());
        String day = sp.getString("st_day", "");
        long base = sp.getLong("st_base", 0);
        long off = sp.getLong("st_off", 0);
        long last = sp.getLong("st_last", -1);
        SharedPreferences.Editor e = sp.edit();

        if (!today.equals(day)) {
            // first reading of a new day
            if (last >= 0 && total >= last && day.equals(Fmt.dayKeyAgo(1))) {
                base = last;
            } else {
                base = total;
            }
            off = 0;
            e.putString("st_day", today);
        } else if (last >= 0 && total < last) {
            // the phone was restarted, the sensor counts from zero again
            off = Math.round(dayGet("steps", today, 0f));
            base = 0;
        }

        long steps = off + Math.max(0L, total - base);
        e.putLong("st_base", base);
        e.putLong("st_off", off);
        e.putLong("st_last", total);
        e.putFloat("d_steps_" + today, (float) steps);
        e.apply();
    }

    // ------------------------------------------------------------------
    // workout history
    // ------------------------------------------------------------------

    static List<Run> runs() {
        ArrayList<Run> list = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString("runs", "[]"));
            for (int i = 0; i < a.length(); i++) {
                list.add(Run.fromJson(a.getJSONObject(i)));
            }
        } catch (JSONException e) {
            // ignore broken data, start with an empty list
        }
        return list;
    }

    private static void saveRuns(List<Run> list) {
        JSONArray a = new JSONArray();
        for (Run r : list) {
            try {
                a.put(r.toJson());
            } catch (JSONException e) {
                // skip this run
            }
        }
        sp.edit().putString("runs", a.toString()).apply();
    }

    static void addRun(Run r) {
        List<Run> list = runs();
        list.add(0, r);
        saveRuns(list);
    }

    static void deleteRun(long id) {
        List<Run> list = runs();
        ArrayList<Run> keep = new ArrayList<>();
        for (Run r : list) {
            if (r.id != id) keep.add(r);
        }
        saveRuns(keep);
    }

    static void clearRuns() {
        sp.edit().putString("runs", "[]").apply();
    }
}
