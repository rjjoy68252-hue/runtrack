package com.runtrack.app;

import android.view.View;

/** One tab of the app. */
abstract class Screen {
    final MainActivity a;

    Screen(MainActivity a) {
        this.a = a;
    }

    abstract View build();

    /** Called once a second while the screen is visible. */
    void tick() {
    }
}
