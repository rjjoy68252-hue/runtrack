package com.runtrack.app;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Number, time and text formatting helpers. */
final class Fmt {
    private Fmt() {}

    static String clock(long sec) {
        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        long s = sec % 60;
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s);
    }

    static String num(long n) {
        return String.format(Locale.US, "%,d", n);
    }

    static double unitMeters() {
        return Prefs.miles() ? 1609.344 : 1000.0;
    }

    static String unit() {
        return Prefs.miles() ? "mi" : "km";
    }

    static String distNum(double meters) {
        return String.format(Locale.US, "%.2f", meters / unitMeters());
    }

    static String dist(double meters) {
        return distNum(meters) + " " + unit();
    }

    /** Pace as mm:ss per km (or per mile). */
    static String pace(double meters, long sec) {
        if (meters < 50 || sec <= 0) return "--:--";
        long p = Math.round(sec / (meters / unitMeters()));
        return String.format(Locale.US, "%02d:%02d", p / 60, p % 60);
    }

    static String paceWithUnit(double meters, long sec) {
        return pace(meters, sec) + " /" + unit();
    }

    /** Speed in km/h (or mph). */
    static String speed(double meters, long sec) {
        if (meters < 50 || sec <= 0) return "-- " + (Prefs.miles() ? "mph" : "km/h");
        double perHour = (meters / unitMeters()) / (sec / 3600.0);
        return String.format(Locale.US, "%.1f %s", perHour, Prefs.miles() ? "mph" : "km/h");
    }

    /** Workout type: 0 run, 1 walk, 2 cycle. */
    static int calories(double meters, int type) {
        double perKmPerKg = type == 0 ? 1.036 : (type == 1 ? 0.57 : 0.4);
        return (int) Math.round(Prefs.weightKg() * (meters / 1000.0) * perKmPerKg);
    }

    static String modeName(int type) {
        switch (type) {
            case 1:
                return L.s("Walk", "হাঁটা");
            case 2:
                return L.s("Cycle", "সাইকেল");
            default:
                return L.s("Run", "দৌড়");
        }
    }

    static String modeIcon(int type) {
        switch (type) {
            case 1:
                return "🚶";
            case 2:
                return "🚴";
            default:
                return "🏃";
        }
    }

    static double stepsToMeters(long steps) {
        return steps * 0.75;
    }

    static int stepCalories(long steps) {
        return (int) Math.round(steps * Prefs.weightKg() * 0.0005);
    }

    /** Minutes as "7h 30m" / "৭ ঘ ৩০ মি" style text (digits stay Latin). */
    static String hm(int minutes) {
        int h = minutes / 60;
        int m = minutes % 60;
        return Prefs.bengali() ? (h + " ঘ " + m + " মি") : (h + "h " + m + "m");
    }

    static String date(long millis) {
        return new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(new Date(millis));
    }

    static String dayKey(long millis) {
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date(millis));
    }

    static String dayKeyAgo(int days) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -days);
        return dayKey(c.getTimeInMillis());
    }

    static String dayShort(int daysAgo) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -daysAgo);
        int d = c.get(Calendar.DAY_OF_WEEK); // Sunday = 1
        String[] en = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        String[] bn = {"রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি"};
        return (Prefs.bengali() ? bn : en)[d - 1];
    }

    static String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (Prefs.bengali()) {
            if (h >= 5 && h < 12) return "সুপ্রভাত";
            if (h >= 12 && h < 16) return "শুভ দুপুর";
            if (h >= 16 && h < 19) return "শুভ বিকেল";
            if (h >= 19 && h < 22) return "শুভ সন্ধ্যা";
            return "শুভ রাত্রি";
        }
        if (h >= 5 && h < 12) return "Good morning";
        if (h >= 12 && h < 17) return "Good afternoon";
        if (h >= 17 && h < 21) return "Good evening";
        return "Good night";
    }
}
