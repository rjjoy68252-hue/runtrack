package com.runtrack.app;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** One saved workout (run, walk or cycle). */
final class Run {
    final long id;        // start time in millis, also used as unique id
    final long seconds;
    final double meters;
    final int calories;
    final String route;   // "lat,lon;lat,lon;..."
    final int type;       // 0 run, 1 walk, 2 cycle

    Run(long id, long seconds, double meters, int calories, String route, int type) {
        this.id = id;
        this.seconds = seconds;
        this.meters = meters;
        this.calories = calories;
        this.route = route;
        this.type = type;
    }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("sec", seconds);
        o.put("m", meters);
        o.put("cal", calories);
        o.put("route", route);
        o.put("type", type);
        return o;
    }

    static Run fromJson(JSONObject o) {
        return new Run(
                o.optLong("id"),
                o.optLong("sec"),
                o.optDouble("m"),
                o.optInt("cal"),
                o.optString("route", ""),
                o.optInt("type", 0));
    }

    /** Encodes up to about 300 points of the route as text. */
    static String encode(List<double[]> pts) {
        int n = pts.size();
        int step = Math.max(1, (int) Math.ceil(n / 300.0));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i += step) {
            appendPoint(sb, pts.get(i));
        }
        if (n > 0 && (n - 1) % step != 0) {
            appendPoint(sb, pts.get(n - 1));
        }
        return sb.toString();
    }

    private static void appendPoint(StringBuilder sb, double[] p) {
        if (sb.length() > 0) sb.append(';');
        sb.append(String.format(Locale.US, "%.5f,%.5f", p[0], p[1]));
    }

    List<double[]> points() {
        ArrayList<double[]> list = new ArrayList<>();
        if (route == null || route.isEmpty()) return list;
        for (String s : route.split(";")) {
            String[] a = s.split(",");
            if (a.length == 2) {
                try {
                    list.add(new double[]{Double.parseDouble(a[0]), Double.parseDouble(a[1])});
                } catch (NumberFormatException e) {
                    // skip bad point
                }
            }
        }
        return list;
    }
}
