package com.runtrack.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.util.Locale;

/** Simple bar chart with day labels and an optional dashed goal line. */
public class BarChartView extends View {
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint goalLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private float[] values = new float[0];
    private String[] labels = new String[0];
    private int color = UI.ACCENT;
    private float goal = -1f;

    public BarChartView(Context c) {
        super(c);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(UI.dp(c, 10));
        goalLine.setStyle(Paint.Style.STROKE);
        goalLine.setStrokeWidth(UI.dp(c, 1));
        goalLine.setColor(UI.withAlpha(UI.GOLD, 0xAA));
        goalLine.setPathEffect(new DashPathEffect(
                new float[]{UI.dp(c, 4), UI.dp(c, 4)}, 0f));
    }

    void set(float[] values, String[] labels, int color, float goal) {
        this.values = values;
        this.labels = labels;
        this.color = color;
        this.goal = goal;
        invalidate();
    }

    private static String fmt(float v) {
        if (v >= 1000f) return String.format(Locale.US, "%.1fk", v / 1000f);
        if (Math.abs(v - Math.rint(v)) < 0.05f) return String.format(Locale.US, "%.0f", v);
        return String.format(Locale.US, "%.1f", v);
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        int n = values.length;
        if (n == 0) return;

        Context c = getContext();
        float w = getWidth();
        float h = getHeight();
        float labelH = UI.dp(c, 18);
        float topPad = UI.dp(c, 16);
        float chartH = h - labelH - topPad;
        if (chartH <= 0) return;
        float baseY = topPad + chartH;

        float max = 0f;
        for (float v : values) max = Math.max(max, v);
        if (goal > 0) max = Math.max(max, goal);
        if (max <= 0f) max = 1f;

        float slot = w / n;
        float barW = Math.min(slot * 0.5f, UI.dp(c, 28));
        float radius = UI.dp(c, 5);

        for (int i = 0; i < n; i++) {
            float v = values[i];
            float bh = v <= 0f ? UI.dp(c, 3) : Math.max(UI.dp(c, 3), chartH * v / max);
            float left = i * slot + (slot - barW) / 2f;
            rect.set(left, baseY - bh, left + barW, baseY);
            bar.setColor(v > 0f ? color : UI.LINE);
            cv.drawRoundRect(rect, radius, radius, bar);

            if (v > 0f) {
                text.setColor(UI.TEXT);
                cv.drawText(fmt(v), i * slot + slot / 2f, baseY - bh - UI.dp(c, 4), text);
            }
            if (i < labels.length) {
                text.setColor(UI.MUTED);
                cv.drawText(labels[i], i * slot + slot / 2f, h - UI.dp(c, 4), text);
            }
        }

        if (goal > 0) {
            float y = baseY - chartH * goal / max;
            cv.drawLine(0, y, w, y, goalLine);
        }
    }
}
