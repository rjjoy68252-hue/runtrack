package com.runtrack.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** GPS workout: run, walk or cycle with live time, distance, pace and route. */
final class WorkoutScreen extends Screen {
    private TextView statusText, timeText, distText, paceText, calText, paceLabel;
    private Button startStopBtn, pauseBtn;
    private RouteView routeView;
    private final TextView[] chips = new TextView[3];

    WorkoutScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        LinearLayout col = UI.page(a);

        statusText = UI.tv(a, "", 15, UI.ACCENT, true);
        statusText.setGravity(Gravity.CENTER);
        col.addView(statusText, UI.lp(a, UI.MATCH, UI.WRAP, 0, 4));

        // mode chips
        LinearLayout chipRow = new LinearLayout(a);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView t = UI.tv(a, Fmt.modeIcon(i) + " " + Fmt.modeName(i), 14, UI.TEXT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, UI.dp(a, 11), 0, UI.dp(a, 11));
            t.setOnClickListener(x -> {
                if (RunState.active) return;
                RunState.mode = idx;
                styleChips();
                updateUi();
            });
            chips[i] = t;
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
            if (i > 0) p.leftMargin = UI.dp(a, 8);
            chipRow.addView(t, p);
        }
        col.addView(chipRow, UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));
        styleChips();

        // main card
        LinearLayout card = UI.hero(a);
        card.setGravity(Gravity.CENTER_HORIZONTAL);

        timeText = UI.tv(a, "00:00:00", 52, UI.TEXT, true);
        timeText.setGravity(Gravity.CENTER);
        card.addView(timeText, UI.lp(a, UI.WRAP, UI.WRAP, 0, 16));
        card.addView(UI.tv(a, L.s("TIME", "সময়"), 12, UI.MUTED, true), UI.lp(a, UI.WRAP, UI.WRAP, 0, 0));

        LinearLayout stats = new LinearLayout(a);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        distText = UI.tv(a, "0.00 km", 22, UI.ACCENT, true);
        paceText = UI.tv(a, "--:-- /km", 22, UI.TEXT, true);
        calText = UI.tv(a, "0 kcal", 22, UI.ORANGE, true);
        paceLabel = UI.tv(a, L.s("PACE", "পেস"), 11, UI.MUTED, true);
        stats.addView(statBlock(distText, UI.tv(a, L.s("DISTANCE", "দূরত্ব"), 11, UI.MUTED, true)),
                new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        stats.addView(statBlock(paceText, paceLabel), new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        stats.addView(statBlock(calText, UI.tv(a, L.s("CALORIES", "ক্যালোরি"), 11, UI.MUTED, true)),
                new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        card.addView(stats, UI.lp(a, UI.MATCH, UI.WRAP, 0, 24));

        routeView = new RouteView(a);
        routeView.setVisibility(View.GONE);
        card.addView(routeView, UI.lp(a, UI.MATCH, UI.dp(a, 180), 0, 18));
        col.addView(card, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // buttons
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        startStopBtn = UI.button(a, "", true);
        pauseBtn = UI.button(a, "", false);
        pauseBtn.setVisibility(View.GONE);
        row.addView(startStopBtn, new LinearLayout.LayoutParams(0, UI.WRAP, 1f));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        pp.leftMargin = UI.dp(a, 10);
        row.addView(pauseBtn, pp);
        col.addView(row, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        startStopBtn.setOnClickListener(x -> {
            if (RunState.active) {
                stopRun();
            } else {
                startRunFlow();
            }
        });
        pauseBtn.setOnClickListener(x -> {
            if (RunState.paused) {
                RunState.resume();
            } else {
                RunState.pause();
            }
            updateUi();
        });

        TextView hint = UI.tv(a, "GPS REQUIRED  •  OUTDOOR", 11, UI.MUTED, true);
        hint.setGravity(Gravity.CENTER);
        col.addView(hint, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        col.addView(Widgets.weeklyGoalCard(a, Prefs.runs()), UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        View v = UI.scroll(a, col);
        updateUi();
        return v;
    }

    private View statBlock(TextView value, TextView label) {
        LinearLayout b = new LinearLayout(a);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER_HORIZONTAL);
        value.setGravity(Gravity.CENTER);
        b.addView(value, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        b.addView(label, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        return b;
    }

    private void styleChips() {
        for (int i = 0; i < 3; i++) {
            boolean sel = i == RunState.mode;
            chips[i].setBackground(UI.round(sel ? UI.ACCENT : UI.CARD_TOP, 14, a));
            chips[i].setTextColor(sel ? 0xFF0A0C0E : UI.TEXT);
            chips[i].setAlpha(RunState.active && !sel ? 0.4f : 1f);
        }
    }

    private void updateUi() {
        if (timeText == null) return;
        boolean act = RunState.active;
        boolean pz = RunState.paused;

        if (!act) {
            statusText.setText(L.s("READY", "প্রস্তুত"));
        } else if (pz) {
            statusText.setText(L.s("PAUSED", "বিরতি"));
        } else {
            statusText.setText(L.s("IN PROGRESS", "চলছে"));
        }

        long sec = RunState.elapsedMs() / 1000;
        double m = RunState.meters;
        timeText.setText(Fmt.clock(sec));
        distText.setText(Fmt.dist(m));
        if (RunState.mode == 2) {
            paceLabel.setText(L.s("SPEED", "গতি"));
            paceText.setText(Fmt.speed(m, sec));
        } else {
            paceLabel.setText(L.s("PACE", "পেস"));
            paceText.setText(Fmt.paceWithUnit(m, sec));
        }
        calText.setText(Fmt.calories(m, RunState.mode) + " kcal");

        if (act) {
            startStopBtn.setText(L.s("STOP", "শেষ করুন"));
            startStopBtn.setTextColor(UI.TEXT);
            startStopBtn.setBackground(UI.round(UI.DANGER, 14, a));
            pauseBtn.setVisibility(View.VISIBLE);
            pauseBtn.setText(pz ? L.s("RESUME", "চালু করুন") : L.s("PAUSE", "বিরতি"));
        } else {
            startStopBtn.setText(L.s("START ", "শুরু করুন  ") + Fmt.modeName(RunState.mode).toUpperCase());
            startStopBtn.setTextColor(0xFF0A0C0E);
            startStopBtn.setBackground(UI.round(UI.ACCENT, 14, a));
            pauseBtn.setVisibility(View.GONE);
        }
        styleChips();

        if (RunState.points.size() >= 2) {
            routeView.setPoints(RunState.points);
            routeView.setVisibility(View.VISIBLE);
        } else {
            routeView.setVisibility(View.GONE);
        }

        if (act && Prefs.keepScreenOn()) {
            a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            a.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    @Override
    void tick() {
        updateUi();
    }

    /** Also called by the activity after the location permission was granted. */
    void startRunFlow() {
        if (a.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            a.requestLocation();
            return;
        }
        LocationManager lm = (LocationManager) a.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null || !lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(a, L.s("Please turn on GPS", "অনুগ্রহ করে GPS চালু করুন"),
                    Toast.LENGTH_LONG).show();
            return;
        }
        RunState.begin();
        Intent i = new Intent(a, RunningService.class);
        i.setAction(RunningService.ACTION_START);
        a.startForegroundService(i);
        updateUi();
    }

    private void stopRun() {
        Run r = RunState.finishRun();
        Intent i = new Intent(a, RunningService.class);
        i.setAction(RunningService.ACTION_STOP);
        a.startService(i);
        if (r != null) {
            Prefs.addRun(r);
            new AlertDialog.Builder(a)
                    .setTitle(L.s("Workout saved", "ওয়ার্কআউট সেভ হয়েছে"))
                    .setMessage(Widgets.summary(r))
                    .setPositiveButton("OK", null)
                    .show();
        } else {
            Toast.makeText(a, L.s("Too short, not saved", "খুব ছোট, সেভ হয়নি"),
                    Toast.LENGTH_SHORT).show();
        }
        updateUi();
    }
}
