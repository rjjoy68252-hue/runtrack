package com.runtrack.app;

import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Home dashboard: today's steps, water, sleep, heart rate, streak and a 7-day chart. */
final class HomeScreen extends Screen {
    private RingView ring;
    private TextView distVal, calVal, goalVal;
    private TextView waterVal, sleepVal, hrVal;
    private List<Run> runs;

    HomeScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        runs = Prefs.runs();
        LinearLayout col = UI.page(a);

        String nm = Prefs.name();
        col.addView(UI.tv(a, Fmt.greeting() + (nm.isEmpty() ? "" : ", " + nm), 24, UI.TEXT, true),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 4));
        String date = new SimpleDateFormat("EEEE, dd MMM yyyy", Locale.US).format(new Date());
        col.addView(UI.tv(a, date, 12, UI.MUTED, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 2));

        // permission / sensor note
        if (!a.hasActivityPermission()) {
            LinearLayout note = UI.card(a);
            note.addView(UI.tv(a,
                    L.s("Allow \"Physical activity\" to count your steps.",
                            "স্টেপ গোনার জন্য \"Physical activity\" অনুমতি দিন।"),
                    14, UI.TEXT, false));
            Button b = UI.button(a, L.s("Allow", "অনুমতি দিন"), true);
            b.setOnClickListener(x -> a.requestActivity());
            note.addView(b, UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));
            col.addView(note, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        } else if (!a.stepSensorPresent()) {
            LinearLayout note = UI.card(a);
            note.addView(UI.tv(a,
                    L.s("This phone has no step sensor. Workouts still work with GPS.",
                            "এই ফোনে স্টেপ সেন্সর নেই। GPS দিয়ে ওয়ার্কআউট ঠিকই চলবে।"),
                    14, UI.TEXT, false));
            col.addView(note, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        }

        // hero: steps ring + distance + calories
        LinearLayout hero = UI.hero(a);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        ring = new RingView(a);
        hero.addView(ring, new LinearLayout.LayoutParams(UI.dp(a, 140), UI.dp(a, 140)));

        LinearLayout right = new LinearLayout(a);
        right.setOrientation(LinearLayout.VERTICAL);
        distVal = UI.tv(a, "0.00 km", 20, UI.TEXT, true);
        calVal = UI.tv(a, "0 kcal", 20, UI.ORANGE, true);
        goalVal = UI.tv(a, "0%", 20, UI.ACCENT, true);
        addStat(right, L.s("DISTANCE", "দূরত্ব"), distVal, false);
        addStat(right, L.s("CALORIES", "ক্যালোরি"), calVal, true);
        addStat(right, L.s("STEP GOAL", "স্টেপ লক্ষ্য"), goalVal, true);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        rp.leftMargin = UI.dp(a, 16);
        hero.addView(right, rp);
        col.addView(hero, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // start workout
        Button start = UI.button(a, "▶  " + L.s("Start workout", "ওয়ার্কআউট শুরু করুন"), true);
        start.setTextSize(17);
        start.setOnClickListener(x -> a.go(1));
        col.addView(start, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // water / sleep / heart
        LinearLayout minis = new LinearLayout(a);
        minis.setOrientation(LinearLayout.HORIZONTAL);
        waterVal = mini(minis, "💧", L.s("WATER", "পানি"), UI.BLUE, true);
        sleepVal = mini(minis, "😴", L.s("SLEEP", "ঘুম"), UI.PURPLE, false);
        hrVal = mini(minis, "❤️", L.s("HEART", "হার্ট"), UI.RED, false);
        col.addView(minis, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // streak
        int streak = Stats.streak(runs);
        LinearLayout sc = UI.card(a, UI.blend(UI.GOLD, UI.BG, 0.85f), UI.blend(UI.GOLD, UI.BG, 0.94f),
                UI.withAlpha(UI.GOLD, 0x66));
        LinearLayout sr = UI.row(a);
        sr.addView(UI.tv(a, "🔥", 30, UI.TEXT, false), new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        LinearLayout st = new LinearLayout(a);
        st.setOrientation(LinearLayout.VERTICAL);
        st.addView(UI.tv(a, L.s(streak + " day streak", streak + " দিনের স্ট্রিক"), 18, UI.GOLD, true));
        st.addView(UI.tv(a, L.s("Best: ", "সেরা: ") + Prefs.bestStreak() + L.s(" days", " দিন")
                + "  •  " + L.s("Reach your step goal or work out daily",
                "রোজ স্টেপ লক্ষ্য বা ওয়ার্কআউট করুন"), 11, UI.MUTED, false));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        sp.leftMargin = UI.dp(a, 12);
        sr.addView(st, sp);
        sc.addView(sr);
        col.addView(sc, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // steps chart
        col.addView(Widgets.chartCard(a, L.s("STEPS  •  LAST 7 DAYS", "স্টেপ  •  গত ৭ দিন"),
                Stats.series("steps", 7), Stats.labels(7), UI.ACCENT, Prefs.stepGoal()),
                UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        col.addView(Widgets.weeklyGoalCard(a, runs), UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // last workout
        if (!runs.isEmpty()) {
            Run r = runs.get(0);
            LinearLayout card = UI.card(a);
            card.addView(UI.tv(a, L.s("LAST WORKOUT", "শেষ ওয়ার্কআউট"), 12, UI.MUTED, true));
            card.addView(UI.tv(a, Fmt.modeIcon(r.type) + "  " + Fmt.dist(r.meters), 24, UI.ACCENT, true),
                    UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));
            String pace = r.type == 2 ? Fmt.speed(r.meters, r.seconds) : Fmt.paceWithUnit(r.meters, r.seconds);
            card.addView(UI.tv(a, Fmt.date(r.id) + "\n" + Fmt.clock(r.seconds) + "  •  " + pace
                    + "  •  " + r.calories + " kcal", 13, UI.TEXT, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 4));
            card.setOnClickListener(x -> a.go(3));
            col.addView(card, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        }

        View v = UI.scroll(a, col);
        update();
        return v;
    }

    private void addStat(LinearLayout parent, String label, TextView value, boolean gap) {
        TextView l = UI.tv(a, label, 10, UI.MUTED, true);
        parent.addView(l, UI.lp(a, UI.WRAP, UI.WRAP, 0, gap ? 10 : 0));
        parent.addView(value, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
    }

    private TextView mini(LinearLayout row, String emoji, String label, int color, boolean first) {
        LinearLayout card = UI.card(a);
        int p = UI.dp(a, 12);
        card.setPadding(p, p, p, p);
        card.addView(UI.tv(a, emoji + " " + label, 11, UI.MUTED, true));
        TextView val = UI.tv(a, "--", 17, color, true);
        card.addView(val, UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));
        card.setOnClickListener(x -> a.go(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
        if (!first) lp.leftMargin = UI.dp(a, 8);
        row.addView(card, lp);
        return val;
    }

    private void update() {
        if (ring == null) return;
        long steps = Prefs.stepsToday();
        int goal = Math.max(1, Prefs.stepGoal());
        ring.set(steps / (float) goal, UI.ACCENT, Fmt.num(steps),
                L.s("of ", "লক্ষ্য ") + Fmt.num(goal));

        double[] t = Stats.today(runs);
        distVal.setText(Fmt.dist(t[0]));
        calVal.setText(Math.round(t[1]) + " kcal");
        goalVal.setText(Math.min(999, Math.round(100f * steps / goal)) + "%");

        String today = Fmt.dayKey(System.currentTimeMillis());
        waterVal.setText(Math.round(Prefs.dayGet("water", today, 0f)) + " ml");
        float sleep = Prefs.dayGet("sleep", today, -1f);
        sleepVal.setText(sleep < 0 ? "--" : Fmt.hm(Math.round(sleep)));
        float[] hr = Stats.recent("hr", 60);
        hrVal.setText(hr[0] < 0 ? "--" : Math.round(hr[0]) + " bpm");
    }

    @Override
    void tick() {
        update();
    }
}
