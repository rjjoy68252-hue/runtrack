package com.runtrack.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Theme colors, developer credit and view-building helpers. */
final class UI {
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    interface IntSaver {
        void save(int v);
    }

    // ---- theme (changed from Settings) ----
    static int BG = 0xFF07090D;
    static int CARD_TOP = 0xFF1A212A;
    static int CARD_BOTTOM = 0xFF11161C;
    static int STROKE = 0xFF2B343F;
    static int LINE = 0xFF242B33;
    static int ACCENT = 0xFFB8FF3A;
    static int ACCENT_DARK = 0xFF8EE02B;

    // ---- fixed colors ----
    static final int GOLD = 0xFFF2C46D;
    static final int BLUE = 0xFF4DA3FF;
    static final int PURPLE = 0xFFA78BFA;
    static final int ORANGE = 0xFFFF9A52;
    static final int RED = 0xFFFF5C70;
    static final int TEXT = 0xFFFFFFFF;
    static final int MUTED = 0xFF8B96A1;
    static final int DANGER = 0xFFFF4D5E;

    static final String DEV_NAME = "MD HAMAYET HOSSAIN";
    static final String FB_URL = "https://www.facebook.com/share/1CQMntvP8J/";

    /** Accent color choices: {en, bn, color}. */
    static final String[] ACCENT_EN = {"Lime", "Sky", "Orange", "Pink", "Purple", "Gold", "Mint", "Red"};
    static final String[] ACCENT_BN = {"লাইম", "আকাশি", "কমলা", "গোলাপি", "বেগুনি", "সোনালি", "পুদিনা", "লাল"};
    static final int[] ACCENT_COLORS = {
            0xFFB8FF3A, 0xFF4DB8FF, 0xFFFF9A3C, 0xFFFF5FA2,
            0xFFB388FF, 0xFFF2C46D, 0xFF3DDC97, 0xFFFF5C5C
    };

    /** Background style choices. */
    static final String[] BG_EN = {"Midnight", "Navy", "Forest", "Charcoal"};
    static final String[] BG_BN = {"মধ্যরাত", "নেভি", "বন", "কয়লা"};
    // {bg, cardTop, cardBottom, stroke, line}
    static final int[][] BG_SETS = {
            {0xFF07090D, 0xFF1A212A, 0xFF11161C, 0xFF2B343F, 0xFF242B33},
            {0xFF060B16, 0xFF16233A, 0xFF0E1627, 0xFF263650, 0xFF1D2B44},
            {0xFF060D09, 0xFF152A1F, 0xFF0E1A13, 0xFF24402F, 0xFF1B3325},
            {0xFF0C0C0E, 0xFF232326, 0xFF18181B, 0xFF37373C, 0xFF2D2D31}
    };

    private UI() {}

    /** Loads the saved colors. Call after Prefs.init and again after a change. */
    static void applyTheme() {
        int a = Math.max(0, Math.min(ACCENT_COLORS.length - 1, Prefs.accentIndex()));
        int b = Math.max(0, Math.min(BG_SETS.length - 1, Prefs.bgIndex()));
        ACCENT = ACCENT_COLORS[a];
        ACCENT_DARK = blend(ACCENT, 0xFF000000, 0.22f);
        BG = BG_SETS[b][0];
        CARD_TOP = BG_SETS[b][1];
        CARD_BOTTOM = BG_SETS[b][2];
        STROKE = BG_SETS[b][3];
        LINE = BG_SETS[b][4];
    }

    static String accentName() {
        int i = Math.max(0, Math.min(ACCENT_EN.length - 1, Prefs.accentIndex()));
        return Prefs.bengali() ? ACCENT_BN[i] : ACCENT_EN[i];
    }

    static String bgName() {
        int i = Math.max(0, Math.min(BG_EN.length - 1, Prefs.bgIndex()));
        return Prefs.bengali() ? BG_BN[i] : BG_EN[i];
    }

    /** Mixes two colors: t = 0 gives a, t = 1 gives b. */
    static int blend(int a, int b, float t) {
        int r = Math.round(Color.red(a) * (1 - t) + Color.red(b) * t);
        int g = Math.round(Color.green(a) * (1 - t) + Color.green(b) * t);
        int bl = Math.round(Color.blue(a) * (1 - t) + Color.blue(b) * t);
        return Color.rgb(r, g, bl);
    }

    static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable gradient(Context c, int top, int bottom, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static LinearLayout card(Context c) {
        return card(c, CARD_TOP, CARD_BOTTOM, STROKE);
    }

    static LinearLayout card(Context c, int top, int bottom, int stroke) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(gradient(c, top, bottom, 20, stroke));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    /** Big highlighted card that follows the accent color. */
    static LinearLayout hero(Context c) {
        return card(c, blend(ACCENT, BG, 0.82f), blend(ACCENT, BG, 0.94f), withAlpha(GOLD, 0x66));
    }

    /** Card tinted with a given color (water = blue, sleep = purple, ...). */
    static LinearLayout tintedCard(Context c, int tint) {
        return card(c, blend(tint, BG, 0.84f), blend(tint, BG, 0.94f), withAlpha(tint, 0x55));
    }

    static Button button(Context c, String label, boolean filled) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        if (filled) {
            b.setTextColor(0xFF0A0C0E);
            GradientDrawable g = new GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT, new int[]{ACCENT, ACCENT_DARK});
            g.setCornerRadius(dp(c, 14));
            b.setBackground(g);
        } else {
            b.setTextColor(TEXT);
            b.setBackground(round(LINE, 14, c));
        }
        b.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        return b;
    }

    static LinearLayout.LayoutParams lp(Context c, int w, int h, float weight, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.topMargin = dp(c, topDp);
        return p;
    }

    static LinearLayout row(Context c) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    static LinearLayout page(Context c) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 16);
        col.setPadding(p, dp(c, 4), p, p);
        return col;
    }

    static ScrollView scroll(Context c, LinearLayout col) {
        ScrollView sv = new ScrollView(c);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(col, new ViewGroup.LayoutParams(MATCH, WRAP));
        return sv;
    }

    static View divider(Context c) {
        View d = new View(c);
        d.setBackgroundColor(LINE);
        d.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(c, 1)));
        return d;
    }

    /** A "label ........ control" settings row. */
    static View settingRow(Context c, String label, View control) {
        LinearLayout row = row(c);
        row.setPadding(0, dp(c, 10), 0, dp(c, 10));
        TextView t = tv(c, label, 15, TEXT, false);
        row.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(control, new LinearLayout.LayoutParams(WRAP, WRAP));
        return row;
    }

    /** "- value +" control. */
    static LinearLayout stepper(final Context c, int initial, final int min, final int max,
                                final int step, final String suffix, final IntSaver saver) {
        final int[] value = {initial};
        LinearLayout box = row(c);

        final TextView val = tv(c, initial + " " + suffix, 15, TEXT, true);
        val.setGravity(Gravity.CENTER);
        Button minus = button(c, "−", false);
        Button plus = button(c, "+", false);
        minus.setPadding(dp(c, 14), dp(c, 6), dp(c, 14), dp(c, 6));
        plus.setPadding(dp(c, 14), dp(c, 6), dp(c, 14), dp(c, 6));

        minus.setOnClickListener(x -> {
            value[0] = Math.max(min, value[0] - step);
            saver.save(value[0]);
            val.setText(value[0] + " " + suffix);
        });
        plus.setOnClickListener(x -> {
            value[0] = Math.min(max, value[0] + step);
            saver.save(value[0]);
            val.setText(value[0] + " " + suffix);
        });

        box.addView(minus, new LinearLayout.LayoutParams(WRAP, WRAP));
        box.addView(val, new LinearLayout.LayoutParams(dp(c, 84), WRAP));
        box.addView(plus, new LinearLayout.LayoutParams(WRAP, WRAP));
        return box;
    }

    /** Horizontal progress bar, frac between 0 and 1. */
    static View progressBar(Context c, float frac, int color) {
        float f = Math.max(0f, Math.min(1f, frac));
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackground(round(LINE, 6, c));
        View fill = new View(c);
        fill.setBackground(round(color, 6, c));
        View rest = new View(c);
        bar.addView(fill, new LinearLayout.LayoutParams(0, MATCH, f));
        bar.addView(rest, new LinearLayout.LayoutParams(0, MATCH, 1f - f));
        return bar;
    }
}
