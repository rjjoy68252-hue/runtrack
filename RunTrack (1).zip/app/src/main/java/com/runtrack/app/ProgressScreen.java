package com.runtrack.app;

import android.app.AlertDialog;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

/** Totals, charts, badges and the workout history. */
final class ProgressScreen extends Screen {

    ProgressScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        LinearLayout col = UI.page(a);
        col.addView(UI.tv(a, L.s("Progress", "অগ্রগতি"), 24, UI.TEXT, true));

        List<Run> runs = Prefs.runs();
        double totalM = 0;
        long totalS = 0;
        int totalCal = 0;
        double longest = 0;
        double bestPace = 0; // seconds per unit, lower is better (runs only)
        for (Run r : runs) {
            totalM += r.meters;
            totalS += r.seconds;
            totalCal += r.calories;
            if (r.meters > longest) longest = r.meters;
            if (r.type == 0 && r.meters >= 500) {
                double sp = r.seconds / (r.meters / Fmt.unitMeters());
                if (bestPace == 0 || sp < bestPace) bestPace = sp;
            }
        }
        String best = "--:--";
        if (bestPace > 0) {
            long p = Math.round(bestPace);
            best = String.format(Locale.US, "%02d:%02d /%s", p / 60, p % 60, Fmt.unit());
        }

        col.addView(Widgets.pair(a,
                Widgets.statCard(a, L.s("WORKOUTS", "ওয়ার্কআউট"), String.valueOf(runs.size())),
                Widgets.statCard(a, L.s("TOTAL DISTANCE", "মোট দূরত্ব"), Fmt.dist(totalM))),
                UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        col.addView(Widgets.pair(a,
                Widgets.statCard(a, L.s("TOTAL TIME", "মোট সময়"), Fmt.clock(totalS)),
                Widgets.statCard(a, L.s("CALORIES", "ক্যালোরি"), totalCal + " kcal")),
                UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        col.addView(Widgets.pair(a,
                Widgets.statCard(a, L.s("LONGEST", "সবচেয়ে লম্বা"), Fmt.dist(longest)),
                Widgets.statCard(a, L.s("BEST RUN PACE", "সেরা দৌড়ের পেস"), best)),
                UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        col.addView(Widgets.weeklyGoalCard(a, runs), UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // charts
        String[] labels = Stats.labels(7);
        col.addView(Widgets.chartCard(a, L.s("STEPS  •  7 DAYS", "স্টেপ  •  ৭ দিন"),
                Stats.series("steps", 7), labels, UI.ACCENT, Prefs.stepGoal()),
                UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        col.addView(Widgets.chartCard(a,
                L.s("WORKOUT DISTANCE (" + Fmt.unit() + ")", "ওয়ার্কআউট দূরত্ব (" + Fmt.unit() + ")"),
                Stats.workoutSeries(runs, 7), labels, UI.ORANGE, -1f),
                UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));
        col.addView(Widgets.chartCard(a, L.s("WATER (ml)  •  7 DAYS", "পানি (ml)  •  ৭ দিন"),
                Stats.series("water", 7), labels, UI.BLUE, Prefs.waterGoal()),
                UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // badges
        int streak = Stats.streak(runs);
        col.addView(UI.tv(a, L.s("BADGES", "ব্যাজ"), 12, UI.MUTED, true), UI.lp(a, UI.WRAP, UI.WRAP, 0, 20));
        List<Stats.Badge> badges = Stats.badges(runs, streak);
        for (int i = 0; i < badges.size(); i += 3) {
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = i; j < i + 3; j++) {
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, UI.WRAP, 1f);
                if (j > i) p.leftMargin = UI.dp(a, 8);
                if (j < badges.size()) {
                    row.addView(badgeCell(badges.get(j)), p);
                } else {
                    row.addView(new View(a), p);
                }
            }
            col.addView(row, UI.lp(a, UI.MATCH, UI.WRAP, 0, 8));
        }

        // history
        col.addView(UI.tv(a, L.s("HISTORY", "ইতিহাস"), 12, UI.MUTED, true), UI.lp(a, UI.WRAP, UI.WRAP, 0, 20));
        if (runs.isEmpty()) {
            col.addView(UI.tv(a,
                    L.s("No workouts yet. Start your first one!",
                            "এখনও কোনো ওয়ার্কআউট নেই। প্রথমটা শুরু করুন!"),
                    15, UI.MUTED, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 10));
        }
        for (final Run r : runs) {
            col.addView(runCard(r), UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));
        }
        return UI.scroll(a, col);
    }

    private View badgeCell(final Stats.Badge b) {
        LinearLayout cell = UI.card(a);
        int p = UI.dp(a, 10);
        cell.setPadding(p, p, p, p);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.addView(UI.tv(a, b.emoji, 28, UI.TEXT, false), new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
        TextView title = UI.tv(a, b.title, 11, b.earned ? UI.GOLD : UI.MUTED, true);
        title.setGravity(Gravity.CENTER);
        cell.addView(title, UI.lp(a, UI.WRAP, UI.WRAP, 0, 4));
        cell.setAlpha(b.earned ? 1f : 0.35f);
        cell.setOnClickListener(x -> Toast.makeText(a,
                b.title + ": " + b.desc, Toast.LENGTH_SHORT).show());
        return cell;
    }

    private View runCard(final Run r) {
        LinearLayout card = UI.card(a);
        card.addView(UI.tv(a, Fmt.date(r.id), 13, UI.MUTED, false));
        card.addView(UI.tv(a, Fmt.modeIcon(r.type) + "  " + Fmt.dist(r.meters), 26, UI.ACCENT, true),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 4));
        String pace = r.type == 2 ? Fmt.speed(r.meters, r.seconds) : Fmt.paceWithUnit(r.meters, r.seconds);
        card.addView(UI.tv(a, Fmt.clock(r.seconds) + "  •  " + pace + "  •  " + r.calories + " kcal",
                14, UI.TEXT, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 4));
        card.setOnClickListener(x -> showRunDetail(r));
        return card;
    }

    private void showRunDetail(final Run r) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(a, 16);
        box.setPadding(p, p, p, p);

        RouteView rv = new RouteView(a);
        rv.setPoints(r.points());
        box.addView(rv, new LinearLayout.LayoutParams(UI.MATCH, UI.dp(a, 200)));
        box.addView(UI.tv(a, Widgets.summary(r), 15, UI.TEXT, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 12));

        new AlertDialog.Builder(a)
                .setTitle(Fmt.date(r.id))
                .setView(box)
                .setPositiveButton(L.s("Close", "বন্ধ"), null)
                .setNegativeButton(L.s("Delete", "মুছুন"), (d, w) -> {
                    Prefs.deleteRun(r.id);
                    a.refresh();
                })
                .show();
    }
}
