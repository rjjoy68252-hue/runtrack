package com.runtrack.app;

import android.app.AlertDialog;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Settings: profile, goals, colors, preferences, about. */
final class SettingsScreen extends Screen {

    SettingsScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        LinearLayout col = UI.page(a);
        col.addView(UI.tv(a, L.s("Settings", "সেটিংস"), 24, UI.TEXT, true));

        // ---------------- profile ----------------
        LinearLayout profile = UI.card(a);
        profile.addView(header(L.s("PROFILE", "প্রোফাইল")));

        String nm = Prefs.name();
        Button nameBtn = UI.button(a, nm.isEmpty() ? L.s("Set name", "নাম দিন") : nm, false);
        nameBtn.setOnClickListener(x -> a.promptText(
                L.s("Your name", "আপনার নাম"), Prefs.name(), s -> {
                    Prefs.setName(s.trim());
                    a.refresh();
                }));
        profile.addView(UI.settingRow(a, L.s("Name", "নাম"), nameBtn));
        profile.addView(UI.divider(a));
        profile.addView(UI.settingRow(a, L.s("Height", "উচ্চতা"),
                UI.stepper(a, Prefs.heightCm(), 100, 230, 1, "cm", Prefs::setHeightCm)));
        profile.addView(UI.divider(a));
        profile.addView(UI.settingRow(a, L.s("Weight", "ওজন"),
                UI.stepper(a, Prefs.weightKg(), 20, 300, 1, "kg", Prefs::setWeightKg)));
        col.addView(profile, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- goals ----------------
        LinearLayout goals = UI.card(a);
        goals.addView(header(L.s("DAILY GOALS", "দৈনিক লক্ষ্য")));
        goals.addView(UI.settingRow(a, L.s("Steps", "স্টেপ"),
                UI.stepper(a, Prefs.stepGoal(), 1000, 50000, 500, "", Prefs::setStepGoal)));
        goals.addView(UI.divider(a));
        goals.addView(UI.settingRow(a, L.s("Water", "পানি"),
                UI.stepper(a, Prefs.waterGoal(), 500, 6000, 250, "ml", Prefs::setWaterGoal)));
        goals.addView(UI.divider(a));
        goals.addView(UI.settingRow(a, L.s("Sleep", "ঘুম"),
                UI.stepper(a, Prefs.sleepGoalHours(), 4, 12, 1, L.s("h", "ঘ"), Prefs::setSleepGoalHours)));
        goals.addView(UI.divider(a));
        goals.addView(UI.settingRow(a, L.s("Weekly workout", "সাপ্তাহিক ওয়ার্কআউট"),
                UI.stepper(a, Prefs.weeklyGoal(), 1, 500, 1, Fmt.unit(), Prefs::setWeeklyGoal)));
        col.addView(goals, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- colors ----------------
        LinearLayout colors = UI.card(a);
        colors.addView(header(L.s("COLORS", "রং")));

        colors.addView(UI.tv(a, L.s("Accent color", "মূল রং"), 15, UI.TEXT, false),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));
        colors.addView(swatchRow(true), UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));
        colors.addView(UI.tv(a, UI.accentName(), 12, UI.MUTED, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));

        colors.addView(UI.tv(a, L.s("Background style", "ব্যাকগ্রাউন্ড"), 15, UI.TEXT, false),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 18));
        colors.addView(swatchRow(false), UI.lp(a, UI.MATCH, UI.WRAP, 0, 10));
        colors.addView(UI.tv(a, UI.bgName(), 12, UI.MUTED, false), UI.lp(a, UI.WRAP, UI.WRAP, 0, 6));
        col.addView(colors, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- preferences ----------------
        LinearLayout prefs = UI.card(a);
        prefs.addView(header(L.s("PREFERENCES", "পছন্দ")));

        Button langBtn = UI.button(a, Prefs.bengali() ? "বাংলা" : "English", false);
        langBtn.setOnClickListener(x -> {
            Prefs.setBengali(!Prefs.bengali());
            a.rebuildAll();
        });
        prefs.addView(UI.settingRow(a, L.s("Language", "ভাষা"), langBtn));
        prefs.addView(UI.divider(a));

        Button unitBtn = UI.button(a, Prefs.miles() ? "Miles (mi)" : "Kilometers (km)", false);
        unitBtn.setOnClickListener(x -> {
            Prefs.setMiles(!Prefs.miles());
            a.refresh();
        });
        prefs.addView(UI.settingRow(a, L.s("Distance unit", "দূরত্বের একক"), unitBtn));
        prefs.addView(UI.divider(a));

        Switch remind = new Switch(a);
        remind.setChecked(Prefs.waterRemind());
        remind.setOnCheckedChangeListener((b, on) -> {
            Prefs.setWaterRemind(on);
            if (on) {
                WaterReceiver.schedule(a);
                a.requestNotifications();
            } else {
                WaterReceiver.cancel(a);
            }
        });
        prefs.addView(UI.settingRow(a, L.s("Water reminders", "পানির রিমাইন্ডার"), remind));
        prefs.addView(UI.divider(a));

        Switch keep = new Switch(a);
        keep.setChecked(Prefs.keepScreenOn());
        keep.setOnCheckedChangeListener((b, on) -> Prefs.setKeepScreenOn(on));
        prefs.addView(UI.settingRow(a, L.s("Keep screen on while working out", "ওয়ার্কআউটে স্ক্রিন চালু রাখুন"), keep));
        col.addView(prefs, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- about ----------------
        LinearLayout about = UI.hero(a);
        about.addView(header(L.s("ABOUT", "পরিচিতি")));
        about.addView(UI.tv(a, "RunTrack  v" + a.versionName(), 20, UI.ACCENT, true),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 8));
        about.addView(UI.tv(a, L.s("Developed by", "তৈরি করেছেন"), 13, UI.MUTED, false),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 14));
        about.addView(UI.tv(a, UI.DEV_NAME, 20, UI.TEXT, true), UI.lp(a, UI.WRAP, UI.WRAP, 0, 2));
        Button fb = UI.button(a, L.s("Open Facebook profile", "Facebook প্রোফাইল দেখুন"), true);
        fb.setOnClickListener(x -> a.openFacebook());
        about.addView(fb, UI.lp(a, UI.MATCH, UI.WRAP, 0, 14));
        about.addView(UI.tv(a, L.s("Steps, workouts, water, sleep and more in one place.",
                "স্টেপ, ওয়ার্কআউট, পানি, ঘুম আর আরও অনেক কিছু এক জায়গায়।"), 13, UI.MUTED, false),
                UI.lp(a, UI.WRAP, UI.WRAP, 0, 12));
        col.addView(about, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        // ---------------- data ----------------
        Button clear = UI.button(a, L.s("Clear workout history", "ওয়ার্কআউটের ইতিহাস মুছুন"), false);
        clear.setTextColor(UI.DANGER);
        clear.setOnClickListener(x -> new AlertDialog.Builder(a)
                .setTitle(L.s("Clear all workouts?", "সব ওয়ার্কআউট মুছবেন?"))
                .setMessage(L.s("This cannot be undone.", "এটি আর ফেরত আনা যাবে না।"))
                .setPositiveButton(L.s("Clear", "মুছুন"), (d, w) -> {
                    Prefs.clearRuns();
                    Toast.makeText(a, L.s("History cleared", "ইতিহাস মুছে ফেলা হয়েছে"),
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(L.s("Cancel", "বাতিল"), null)
                .show());
        col.addView(clear, UI.lp(a, UI.MATCH, UI.WRAP, 0, 12));

        return UI.scroll(a, col);
    }

    private TextView header(String s) {
        return UI.tv(a, s, 12, UI.MUTED, true);
    }

    /** Row of round color swatches. accent = true for accent colors, false for backgrounds. */
    private View swatchRow(final boolean accent) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int n = accent ? UI.ACCENT_COLORS.length : UI.BG_SETS.length;
        int selected = accent ? Prefs.accentIndex() : Prefs.bgIndex();
        for (int i = 0; i < n; i++) {
            final int idx = i;
            View s = new View(a);
            int fill = accent ? UI.ACCENT_COLORS[i] : UI.BG_SETS[i][1];
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(fill);
            g.setStroke(UI.dp(a, i == selected ? 3 : 1), i == selected ? UI.TEXT : UI.STROKE);
            s.setBackground(g);
            s.setOnClickListener(x -> {
                if (accent) {
                    Prefs.setAccentIndex(idx);
                } else {
                    Prefs.setBgIndex(idx);
                }
                a.applyThemeAndRebuild();
            });
            int size = UI.dp(a, accent ? 34 : 44);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(size, size);
            if (i > 0) p.leftMargin = UI.dp(a, accent ? 8 : 12);
            row.addView(s, p);
        }
        return row;
    }
}
